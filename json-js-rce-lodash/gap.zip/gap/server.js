const express = require('express');
const cons = require('consolidate');
const path = require('path');

const app = express();

app.engine('html', cons.lodash);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');

app.use(express.json());

app.post('/render', (req, res) => {
  res.render('index', req.body, (err, html) => {
    if (err) return res.sendStatus(500);
    res.send(html);
  });
});

app.listen(3000, () => console.log('listening on 3000'));
