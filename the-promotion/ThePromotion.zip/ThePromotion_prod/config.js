const crypto = require('crypto');
const JWT_SECRET = crypto.randomBytes(32).toString('base64url');
console.log('[CTF] JWT secret:', JWT_SECRET);

module.exports = {
    JWT_SECRET,
    FLAG: 'FLAG{0h_y0u_got_m3}'
};
