const jwt = require('jsonwebtoken');
const config = require('../config');

module.exports = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(401).json({ message: 'No token' });

    const token = authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'No token' });

    const header = JSON.parse(Buffer.from(token.split('.')[0], 'base64').toString());
    if (header.alg === 'none') {
        user = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
        req.user = user;
        return next();
    }

    jwt.verify(token, config.JWT_SECRET, { algorithms: ['HS256'] }, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token' });
        req.user = user;
        next();
    });
};
