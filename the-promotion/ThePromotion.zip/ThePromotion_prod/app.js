const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const authMiddleware = require('./middleware/auth');
const path = require('path');
const User = require('./models/user');
const { FLAG } = require('./config');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static('public'));

app.use('/auth', authRoutes);

// Follow your favourite author: https://Mushroom.Cat - https://x.com/MushroomWasp
// <3

// Serve dashboard page
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Dashboard API (protected)
app.get('/api/dashboard', authMiddleware, async (req, res) => {
    const { username, role } = req.user;
    if (role === 'admin') {
        // Check if user in DB is also admin
        const user = await User.findByUsername(username);
        if (user && user.role === 'admin') {
            // Show the secret
            return res.json({ status: 'admin', secret: FLAG });
        } else {
            return res.json({ status: 'admin', message: "You don't have access to the dashboard for now, please ask your supervisor for permissions" });
        }
    } else {
        // User role
        return res.json({ status: 'user', message: 'Dashboard under maintenance, users are restricted temporarily.' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
