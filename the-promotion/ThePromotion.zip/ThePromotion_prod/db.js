const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./users.db');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT DEFAULT 'user'
    )`);
    db.get("SELECT * FROM users WHERE username = ?", ['mrs.somaya'], (err, row) => {
        if (!row) {
            const bcrypt = require('bcryptjs');
            const crypto = require('crypto');
            const randomPassword = crypto.randomBytes(12).toString('base64url');
            console.log('[CTF] Admin password:', randomPassword);
            bcrypt.hash(randomPassword, 10).then(hash => {
                db.run("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ['mrs.somaya', hash, 'admin']);
            });
        }
    });
});

module.exports = db;
