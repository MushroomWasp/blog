const db = require('../db');

exports.create = (username, password, role = 'user') => {
    return new Promise((resolve, reject) => {
        db.run('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, password, role], function(err) {
            if (err) reject(err);
            else resolve(this.lastID);
        });
    });
};

exports.findByUsername = (username) => {
    return new Promise((resolve, reject) => {
        db.get(`SELECT * FROM users WHERE username = '${username}'`, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
};
