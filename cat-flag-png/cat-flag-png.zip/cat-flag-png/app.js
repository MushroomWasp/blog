const express = require('express');
const { exec } = require('child_process');
const path = require('path');

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/execute', (req, res) => {
    const { command } = req.body;
    
    if (!command) {
        return res.json({ 
            success: false, 
            output: 'No command provided!' 
        });
    }

    console.log(`Executing command: ${command}`);

    exec(command, { timeout: 5000 }, (error, stdout, stderr) => {
        let output = '';
        
        if (error) {
            output = `Error`;
        } else {
            output = 'Command executed successfully';
        }

        if (output.length > 1000) {
            output = output.substring(0, 1000) + '\n[OUTPUT TRUNCATED - MAX 1000 CHARS]';
        }

        res.json({
            success: !error,
            output: output,
            command: command
        });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

module.exports = app;
