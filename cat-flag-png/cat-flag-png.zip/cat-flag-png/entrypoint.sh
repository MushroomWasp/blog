#!/bin/sh
set -eu

# --- flush any existing rules (container-local)
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X

# default deny outbound
iptables -P OUTPUT DROP
iptables -P FORWARD DROP
iptables -P INPUT ACCEPT

# allow loopback, established traffic
iptables -A OUTPUT -o lo -j ACCEPT
iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# allow DNS outbound (UDP & TCP port 53)
iptables -A OUTPUT -p udp --dport 53 -m comment --comment "allow-dns-udp" -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -m comment --comment "allow-dns-tcp" -j ACCEPT

# (optional) allow DNS to the node's local resolver IP if you want to restrict to a specific resolver:
# iptables -A OUTPUT -p udp -d 1.2.3.4 --dport 53 -j ACCEPT

# drop everything else (already default DROP). Log only if debugging:
# iptables -A OUTPUT -j LOG --log-prefix "CTF-OUT-DROP: "

# Drop privileges and run the app as non-root user
# su-exec is tiny and available in Alpine; it preserves env
exec su-exec ctf "$@"
