To run

```sh
docker build -t ctf-dns-only:latest .
# must give NET_ADMIN so entrypoint can apply iptables inside the container
docker run --rm -p 3000:3000 --cap-add=NET_ADMIN --name ctf_chal ctf-dns-only:latest
```