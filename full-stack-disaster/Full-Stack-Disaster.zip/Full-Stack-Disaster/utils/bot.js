const puppeteer = require("puppeteer");
const { BASE_URL, ADMIN_PASS } = require("../config/constants");

async function bot_visit(pasteId) {
  const fetch = (await import("node-fetch")).default;
  const url = `${BASE_URL}/paste/${pasteId}`;
  let browser;
  try {
    const loginRes = await fetch(`${BASE_URL}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `username=admin&password=${ADMIN_PASS}`,
      redirect: "manual",
    });

    const rawCookies = loginRes.headers.raw()["set-cookie"];
    const parsedCookies = rawCookies.map((entry) => {
      const parts = entry.split(";");
      const cookiePart = parts[0].split("=");
      if (cookiePart[0] === "csrf_token") {
        cookiePart[1] = "u_aint_gettin_dat"; // 🙃
      }
      return {
        name: cookiePart[0],
        value: cookiePart[1],
        domain: new URL(BASE_URL).hostname,
        path: "/",
        httpOnly: true,
      };
    });

    console.log("Parsed Cookies:", parsedCookies);

    browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--single-process", "--disable-dev-shm-usage"],
    });

    const page = await browser.newPage();

    await page.setCookie(...parsedCookies);

    console.log(`Bot visiting: ${url}`);
    await page.goto(url, { waitUntil: "networkidle2", timeout: 5000 });
  } catch (error) {
    console.error("Bot error:", error);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

module.exports = { bot_visit };
