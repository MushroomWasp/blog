const express = require('express');
const { getData } = require('../db');
const { requireLogin, adminOnly } = require('../middleware/auth');
const authController = require('../controllers/auth.controller');
const pasteController = require('../controllers/paste.controller');
const reportController = require('../controllers/report.controller');
const uploadController = require('../controllers/upload.controller');
const { csrfProtection } = require('../middleware/csrf');
const { htmlBlacklist } = require('../middleware/html');

const router = express.Router();

// Main route
router.get('/', (req, res) => {
    const data = getData();
    res.render('index', { user: data.users.find(u => u.id === req.session.userId) });
});

// Auth routes
router.get('/register', (req, res) => res.render('register'));
router.get('/login', (req, res) => res.render('login'));

router.post('/auth/register', authController.postRegister);
router.post('/auth/login', authController.postLogin);

router.get('/logout', authController.getLogout);

// Paste routes
router.post('/paste', requireLogin, htmlBlacklist, pasteController.postPaste);
router.get('/paste/:id', pasteController.getPaste);
router.get('/my-pastes', requireLogin, pasteController.getMyPastes);

// Report routes
router.get('/report', requireLogin, (req, res) => res.render('report'));
router.post('/report', requireLogin, csrfProtection, reportController.postReport);

// Upload routes
router.get('/upload', adminOnly, uploadController.getUploadForm);
router.post('/upload', adminOnly, csrfProtection, uploadController.postUpload);

module.exports = router;
