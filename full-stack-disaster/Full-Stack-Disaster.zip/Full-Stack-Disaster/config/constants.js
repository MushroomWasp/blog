const path = require('path');
const crypto = require('crypto');

const BASE_URL = 'http://localhost:3000';
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
const ADMIN_PASS = crypto.randomBytes(8).toString('hex');
const FLAG = 'FLAG{Mushrooms_Are_Delicious}';
const SESSION_SECRET = crypto.randomBytes(20).toString('hex');
const SALT = "REDACTED";

module.exports = {
    BASE_URL,
    PORT,
    DATA_FILE,
    ADMIN_PASS,
    FLAG,
    SESSION_SECRET,
    SALT,
};