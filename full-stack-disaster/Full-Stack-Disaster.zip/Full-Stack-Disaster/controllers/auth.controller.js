const { v4: uuidv4 } = require('uuid');
const { getData, saveData } = require('../db');
const { generateCsrfToken } = require('../middleware/csrf');

const getRegister = (req, res) => res.render('register');

const postRegister = (req, res) => {
    const { username, password } = req.body;
    const data = getData();
    if (data.users.find(u => u.username === username)) {
        return res.status(400).send('User already exists.');
    }
    const newUser = { id: uuidv4(), username, password };
    data.users.push(newUser);
    saveData();
    res.redirect('/login');
};

const getLogin = (req, res) => res.render('login');

const postLogin = (req, res) => {
    const { username, password } = req.body;
    const data = getData();
    const user = data.users.find(u => u.username === username && u.password === password);
    if (!user) {
        return res.status(400).send('Invalid username or password.');
    }
    req.session.userId = user.id;
    req.session.username = user.username;
    const csrfToken = generateCsrfToken(user.username);
    res.cookie('csrf_token', csrfToken);
    res.redirect('/');
};

const getLogout = (req, res) => {
    req.session.destroy(() => {
        res.redirect('/');
    });
};

module.exports = {
    getRegister,
    postRegister,
    getLogin,
    postLogin,
    getLogout
};
