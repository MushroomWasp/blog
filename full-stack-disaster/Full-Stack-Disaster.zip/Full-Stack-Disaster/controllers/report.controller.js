const { getData } = require('../db');
const { bot_visit } = require('../utils/bot');

const getReport = (req, res) => {
    res.render('report');
};

const postReport = (req, res) => {
    const { pasteId } = req.body;
    data = getData();
    const paste = data.pastes.find(p => p.id === pasteId);
    if (!paste) {
        return res.status(400).send('Invalid paste ID.');
    }
    bot_visit(pasteId)
    res.send('The admin will review your paste shortly.');
};

module.exports = {
    getReport,
    postReport
};
