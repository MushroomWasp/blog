const fs = require('fs');
const path = require('path');
const { IncomingForm } = require('formidable'); 

const storageDir = path.join(__dirname, '..', 'storage');
if (!fs.existsSync(storageDir)) {
    fs.mkdirSync(storageDir);
}

const getUploadForm = (req, res) => {
    res.render('upload');
};

const postUpload = (req, res) => {
    const form = new IncomingForm({ multiples: false });

    form.parse(req, (err, fields, files) => {
        if (err) {
            return res.status(500).send('Upload error: ' + err.message);
        }

        if (!files.userFile) {
            return res.status(400).send('Please select a file to upload.');
        }

        const userFile = Array.isArray(files.userFile) ? files.userFile[0] : files.userFile;

        let sanitizedFilename = userFile.originalFilename.replace(/(\.\.(\/|\\|$))+/g, '').normalize("NFKC")

        if (!sanitizedFilename.match(/\.(jpg|jpeg|png)$/i)) {
            return res.status(400).send('Only .jpg, .jpeg, .png files are allowed.');
        }

        if (sanitizedFilename.length > 20) {
            sanitizedFilename = sanitizedFilename.substring(0, 20);
        }

        const savePath = path.join(storageDir, sanitizedFilename);

        const readStream = fs.createReadStream(userFile.filepath);
        const writeStream = fs.createWriteStream(savePath);

        readStream.on('error', (err) => {
            return res.status(500).send('Read error: ' + err.message);
        });
        writeStream.on('error', (err) => {
            return res.status(500).send('Write error: ' + err.message);
        });
        writeStream.on('finish', () => {
            fs.unlink(userFile.filepath, (unlinkErr) => {
                if (unlinkErr) {
                    console.error('Failed to delete temp file:', unlinkErr);
                }
            });
            res.send(`File uploaded successfully: ${savePath}`); // edit that
        });

        readStream.pipe(writeStream);
    });
};

module.exports = { getUploadForm ,postUpload };
