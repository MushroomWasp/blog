const { v4: uuidv4 } = require('uuid');
const { getData, saveData } = require('../db');

const postPaste = (req, res) => {
    const { content } = req.body;
    const data = getData();
    const newPaste = {
        id: uuidv4(),
        content,
        userId: req.session.userId,
        createdAt: new Date().toISOString()
    };
    data.pastes.push(newPaste);
    saveData();
    res.redirect(`/paste/${newPaste.id}`);
};

const getPaste = (req, res) => {
    const data = getData();
    const paste = data.pastes.find(p => p.id === req.params.id);
    if (!paste) {
        return res.status(404).send('Paste not found.');
    }
    res.render('paste', { paste });
};

const getMyPastes = (req, res) => {
    const data = getData();
    const userPastes = data.pastes.filter(p => p.userId === req.session.userId);
    res.render('my-pastes', { pastes: userPastes });
};

module.exports = {
    postPaste,
    getPaste,
    getMyPastes
};
