const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { DATA_FILE, ADMIN_PASS, FLAG } = require('../config/constants');

let data = { users: [], pastes: [] };

const loadData = () => {
    if (fs.existsSync(DATA_FILE)) {
        return JSON.parse(fs.readFileSync(DATA_FILE));
    }
    return { users: [], pastes: [] };
};

const saveData = () => {
    const currentData = loadData();
    Object.assign(currentData, data);
    fs.writeFileSync(DATA_FILE, JSON.stringify(currentData, null, 2));
};

const initDB = () => {
    data = loadData();
    if (!data.users.find(u => u.username === 'admin')) {
        const admin = { id: uuidv4(), username: "admin", password: ADMIN_PASS, isAdmin: true };
        data.users.push(admin);
        data.pastes.push({
            id: uuidv4(),
            content: `Copy this: FLAG`,
            userId: admin.id,
            createdAt: new Date().toISOString()
        });
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        console.log(`===========================================`);
        console.log(``);
        console.log(`  admin password: ${ADMIN_PASS}`);
        console.log(``);
        console.log(`===========================================`);
    }
};

const getData = () => {
    data = loadData();
    return data;
};

initDB();

module.exports = {
    getData,
    saveData
};
