const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const cookieParser = require("cookie-parser");
require('./db');
const routes = require('./routes');
const { PORT, SESSION_SECRET } = require('./config/constants');

const app = express();

// Middleware
app.set('view engine', 'ejs');
app.use((req, res, next) => {
  req.url = req.url.replace(/\/{2,}/g, '/');
  req.url = require("path").normalize(req.url);
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self' cdnjs.cloudflare.com 'unsafe-eval';"
  );
  next();
});
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
}));

// Routes
app.use('/', routes);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:80`);
});
