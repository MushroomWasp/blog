const { getData } = require('../db');

const requireLogin = (req, res, next) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    next();
};

const adminOnly = (req, res, next) => {
    requireLogin(req, res, () => {
        const data = getData();
        const user = data.users.find(u => u.id === req.session.userId);
        if (user && user.isAdmin) {
            next();
        } else {
            res.status(403).send('Forbidden: Admins only');
        }
    });
};

module.exports = { requireLogin, adminOnly };
