const crypto = require('crypto');
const { SALT } = require('../config/constants');

function generateCsrfToken(username) {
    return crypto.createHash('md5').update(`${username}:${SALT}`).digest('hex');
}

function csrfProtection(req, res, next) {
    if (req.method !== 'POST') {
        return next();
    }

    const session_csrf_token = req.headers['x-csrf-token'] || req.cookies.csrf_token;

    if (!session_csrf_token) {
        return res.status(403).send('Invalid CSRF token');
    }

    if (req.session && req.session.username) {
        const expectedToken = generateCsrfToken(req.session.username);
        if (session_csrf_token !== expectedToken) {
            return res.status(403).send('Invalid CSRF token');
        }
    }

    next();
}

module.exports = { csrfProtection, generateCsrfToken };
