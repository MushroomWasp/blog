const crypto = require('crypto');

const adminPass = crypto.randomBytes(8).toString('hex')
console.log("--------------------------------")
console.log(`Admin password: ${adminPass}`)
console.log("--------------------------------")

const users = [
    { id: crypto.randomUUID(), username: 'admin', password: adminPass , role: 'super', status: 'approved', message: '' }
];

function findUserByUsername(username) {
    return users.find(user => user.username === username);
}

function findUserById(id) {
    return users.find(user => user.id === id);
}

function addUser(user) {
    const newUser = { id: crypto.randomUUID(), ...user, role: 'user', status: 'pending'};
    users.push(newUser);
    return newUser;
}

function getPendingUsers() {
    return users.filter(user => user.status === 'pending');
}

function approveUser(userId) {
    const user = findUserById(userId);
    if (user) {
        user.status = 'approved';
        return true;
    }
    return false;
}

function updateUserMessage(username, message) {
    const user = findUserByUsername(username);
    if (user) {
        user.message = message;
        return true;
    }
    return false;
}

module.exports = {
    findUserByUsername,
    findUserById,
    addUser,
    getPendingUsers,
    approveUser,
    updateUserMessage,
    adminPass
};
