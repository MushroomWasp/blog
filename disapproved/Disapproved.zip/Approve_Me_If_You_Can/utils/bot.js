const puppeteer = require("puppeteer");
const { adminPass } = require("../models/user");

const BASE_URL = "http://localhost:3001";

async function bot_visit(username) {
  const fetch = (await import("node-fetch")).default;
  const url = `${BASE_URL}/admin/user/${username}`;
  let browser;
  try {
    const loginRes = await fetch(`${BASE_URL}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `username=admin&password=${adminPass}`,
      redirect: "manual",
    });

    const rawCookies = loginRes.headers.raw()["set-cookie"];
    const parsedCookies = rawCookies.map((entry) => {
      const parts = entry.split(";");
      const cookiePart = parts[0].split("=");
      return {
        name: cookiePart[0],
        value: cookiePart[1],
        domain: new URL(BASE_URL).hostname,
        path: "/",
        httpOnly: true,
      };
    });

    browser = await puppeteer.launch({
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--single-process",
        "--disable-dev-shm-usage",
      ],
    });

    const page = await browser.newPage();

    await page.setCookie(...parsedCookies);

    console.log(`Bot visiting: ${url}`);
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 15000 });
  } catch (error) {
    console.error("Bot error:", error);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

module.exports = { bot_visit };
