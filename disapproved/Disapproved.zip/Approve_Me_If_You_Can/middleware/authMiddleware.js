function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next();
    }
    res.redirect('/login');
}

function isSuper(req, res, next) {
    if (req.session.user && req.session.user.role === 'super') {
        return next();
    }
    res.status(403).send('Forbidden');
}

module.exports = { isAuthenticated, isSuper };
