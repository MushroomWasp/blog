const userModel = require('../models/user');

exports.getSignup = (req, res) => {
    res.render('signup');
};

exports.postSignup = (req, res) => {
    const { username, password, message } = req.body;
    if (userModel.findUserByUsername(username)) {
        return res.status(400).send('User already exists.');
    }
    userModel.addUser({ username, password, message });
    res.redirect('/login');
};

exports.getLogin = (req, res) => {
    res.render('login');
};

exports.postLogin = (req, res) => {
    const { username, password } = req.body;
    const user = userModel.findUserByUsername(username);
    if (!user || user.password !== password) {
        return res.status(400).send('Invalid username or password.');
    }

    req.session.user = user;
    
    if (user.role === 'super') {
        return res.redirect('/admin/dashboard');
    }
    res.redirect('/dashboard');
};

exports.getLogout = (req, res) => {
    req.session.destroy(() => {
        res.redirect('/');
    });
};
