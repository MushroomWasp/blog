const userModel = require('../models/user');

const getDashboard = (req, res) => {
    const pendingUsers = userModel.getPendingUsers();
    res.render('adminDashboard', { pendingUsers });
};

const approveUser = (req, res) => {
    const { userId } = req.params;
    const user = userModel.findUserById(userId);
    if (user) {
        user.status = "approved";
    }
    res.redirect('/admin/dashboard');
};

const getMessage = (req, res) => {
    const { username } = req.params;
    const user = userModel.findUserByUsername(username);
    if (user) {
        res.render('message', { viewedUser: user });
    } else {
        res.status(404).send('User not found');
    }
};

const getUser = (req, res) => {    
    const { username } = req.params;
    const user = userModel.findUserByUsername(username);
    if (user) {
        res.render('user_details', { user });
    }
}

module.exports = {
    getDashboard,
    approveUser,
    getMessage,
    getUser
};
