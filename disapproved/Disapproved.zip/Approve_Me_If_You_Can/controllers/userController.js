const { bot_visit } = require('../utils/bot');
const userModel = require('../models/user');

const getDashboard = (req, res) => {
    res.render('dashboard', { user: req.session.user });
};

const updateMessage = (req, res) => {
    const { message } = req.body;
    if (req.session.user) {
        req.session.user.message = message;
        userModel.updateUserMessage(req.session.user.username, message);
    }
    res.redirect('/dashboard');
};

const getReport = (req, res) => {
    res.render('report', { user: req.session.user });
}

const postReport = (req, res) => {
    const { reportedUser } = req.body;

    try {
        bot_visit(reportedUser);
        res.send('Report submitted successfully.');
    } catch (error) {
        console.error('Error submitting report:', error);
        res.status(500).send('An error occurred while submitting the report.');
    }
}

module.exports = {
    getDashboard,
    updateMessage,
    getReport,
    postReport
};