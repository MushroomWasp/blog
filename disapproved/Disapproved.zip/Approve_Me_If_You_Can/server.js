const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const userRoutes = require('./routes/user');

const app = express();
const PORT = 3001;

app.set('view engine', 'ejs');
app.use((req, res, next) => {
  res.setHeader(
    "Content-Security-Policy",
    "default-src cdn.jsdelivr.net; connect-src 'self'"
  );
  next();
});

app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'a-very-secret-key',
    resave: false,
    saveUninitialized: true,
}));
app.use((req, res, next) => {
    res.locals.user = req.session.user;
    req.url = path.posix.normalize(req.url);
    next();
});

app.use(authRoutes);
app.use('/admin', adminRoutes);
app.use(userRoutes);

app.get('/', (req, res) => {
    res.render('index');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
