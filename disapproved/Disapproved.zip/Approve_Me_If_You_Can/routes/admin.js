const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { isAuthenticated, isSuper } = require('../middleware/authMiddleware');

router.get('/dashboard', isAuthenticated, isSuper, adminController.getDashboard);
router.post('/approve/:userId', isAuthenticated, isSuper, adminController.approveUser);
router.get('/message/:username', isAuthenticated, isSuper, adminController.getMessage);
router.get('/user/:username', isAuthenticated, isSuper, adminController.getUser);

module.exports = router;
