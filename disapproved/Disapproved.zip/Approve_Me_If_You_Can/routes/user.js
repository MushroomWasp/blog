const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { isAuthenticated } = require('../middleware/authMiddleware');

router.get('/dashboard', isAuthenticated, userController.getDashboard);
router.post('/update-message', isAuthenticated, userController.updateMessage);
router.get('/report', isAuthenticated, userController.getReport);
router.post('/report', isAuthenticated, userController.postReport);


module.exports = router;
