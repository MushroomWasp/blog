import jwt
import random
import string
from datetime import datetime, timedelta, timezone
from functools import wraps
from flask import request, jsonify, current_app

USERS = {}
TWO_FA_CODES = {}

def generate_2fa_code(length=6):
    return ''.join(random.choices(string.digits, k=length))

def generate_jwt(username, access_level):
    payload = {
        'exp': datetime.now(timezone.utc) + timedelta(hours=1),
        'iat': datetime.now(timezone.utc),
        'sub': username,
        'access': access_level
    }
    return jwt.encode(
        payload,
        current_app.config['SECRET_KEY'],
        algorithm='HS256'
    )

def token_required(required_access_level):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            token = None
            if 'Authorization' in request.headers:
                try:
                    token = request.headers['Authorization'].split(" ")[1]
                except IndexError:
                    return jsonify({"message": "Bearer token malformed"}), 401

            if not token:
                return jsonify({"message": "Token is missing!"}), 401

            try:
                data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
                current_user = data['sub']
                token_access = data.get('access')

                if token_access != required_access_level:
                    return jsonify({"message": f"Invalid access level. Requires '{required_access_level}' access."}), 403

            except jwt.ExpiredSignatureError:
                return jsonify({"message": "Token has expired!"}), 401
            except jwt.InvalidTokenError:
                return jsonify({"message": "Token is invalid!"}), 401

            return f(current_user, *args, **kwargs)
        return decorated_function
    return decorator

