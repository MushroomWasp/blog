from flask import Flask, request, jsonify, render_template, redirect, url_for
from config import Config
import subprocess
from auth import (
    USERS, TWO_FA_CODES, generate_2fa_code, generate_jwt, token_required
)

app = Flask(__name__)
app.config.from_object(Config)

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    data = request.get_json()

    username = data.get('username')
    password = data.get('password')

    if username in TWO_FA_CODES:
        TWO_FA_CODES[username] = None

    if USERS.get(username) == password:
        code = generate_2fa_code()
        TWO_FA_CODES[username] = code
        
        token = generate_jwt(username, '2fa')
        
        print(f"Generated 2FA code for {username}: {code}")
        return jsonify({"message": "2FA required", "token": token})

    return jsonify({"message": "Invalid credentials"}), 401

@app.route('/verify-2fa', methods=['GET', 'POST'])
def verify_2fa():
    if request.method == 'GET':
        return render_template('verify_2fa.html')

    # For POST requests, apply token_required logic
    @token_required('2fa')
    def post_verify_2fa(current_user=None):
        data = request.get_json()
        code = data.get('code')
        
        if not current_user:
            return jsonify({"message": "Auth token is missing!"}), 401

        if TWO_FA_CODES.get(current_user) == code:
            del TWO_FA_CODES[current_user]
            
            token = generate_jwt(current_user, 'full')
            return jsonify({"message": "Login successful!", "token": token})

        return jsonify({"message": "Invalid 2FA code"}), 401
    
    return post_verify_2fa()

@app.route('/dashboard')
def dashboard_page():
    return render_template('dashboard.html')

@app.route('/data', methods=['GET', 'POST'])
@token_required('full')
def dashboard(current_user):
    if request.method == 'POST':
        data = request.get_json()
        command = data.get('command')
        if not command:
            return jsonify({"message": "No command provided"}), 400
        
        try:
            result = subprocess.run(command, shell=True, executable="/bin/bash", capture_output=True, text=True, timeout=20)
            output = result.stdout + result.stderr
            return jsonify({"output": output})
        except subprocess.TimeoutExpired:
            return jsonify({"message": "Command timed out"}), 500
        except Exception as e:
            return jsonify({"message": f"Error executing command: {str(e)}"}), 500
    return jsonify({"message": f"Welcome to the dashboard, {current_user}!"})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5001)

