const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cookieParser = require('cookie-parser');
require('dotenv').config();
const crypto = require('crypto');
const app = express();
const { tasks_viewer } = require('tasks_mangement');
const PORT = process.env.PORT || 4000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Database setup
const db = new sqlite3.Database('/tmp/database.sqlite', (err) => {
  if (err) {
    console.error('Error opening database', err.message);
  } else {
    console.log('Connected to the SQLite database');
    createTables();
  }
});

// Create tables if they don't exist
function createTables() {
  db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tasks table
    db.run(`CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      status TEXT DEFAULT 'pending',
      user_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )`);

    // Messages table
    db.run(`CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content TEXT NOT NULL,
      from_user_id INTEGER,
      to_user_id INTEGER,
      read BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (from_user_id) REFERENCES users (id),
      FOREIGN KEY (to_user_id) REFERENCES users (id)
    )`);
  });
}
const saltRounds = 10;

function insertAdminUser() {
  const password = crypto.randomBytes(20).toString('hex');
  
  // Hash the password
  bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
    if (err) {
      console.error('Error hashing password:', err);
      return;
    }

    // Insert the admin user into the database
    db.run(
      `INSERT INTO users (username, password, role) VALUES (?, ?, ?)`,
      ['admin', hashedPassword, 'admin'],
      function(err) {
        if (err) {
          console.error('Error inserting admin user:', err);
        } else {
          console.log('Admin user inserted successfully');
        }
      }
    );
    db.run(
      `INSERT INTO users (username, password, role) VALUES (?, ?, ?)`,
      ['administrator', hashedPassword, 'admin'],
      function(err) {
        if (err) {
          console.error('Error inserting admin user:', err);
        } else {
          console.log('Administrator user inserted successfully');
        }
      }
    );
  });
}
insertAdminUser();
// Authentication middleware
const authenticateToken = (req, res, next) => {
  const token = req.cookies.token;
  
  if (!token) {
    return res.redirect('/login');
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.redirect('/login');
    }
    req.user = user;
    next();
  });
};

// Role-based authorization middleware
const authorizeRole = (role) => {
  return (req, res, next) => {
    if (req.user.role !== role) {
      return res.status(403).send('Access denied');
    }
    next();
  };
};

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/dashboard', authenticateToken, (req, res) => {
  if (req.user.role === 'admin') {
    res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
  } else {
    res.sendFile(path.join(__dirname, 'public', 'user-dashboard.html'));
  }
});

// API Routes
app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    
    db.run('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', 
      [username, hashedPassword, 'user'], 
      function(err) {
        if (err) {
          if (err.message.includes('UNIQUE constraint failed')) {
            return res.status(400).json({ error: 'Username already exists' });
          }
          return res.status(500).json({ error: err.message });
        }
        
        res.status(201).json({ message: 'User created successfully' });
      }
    );
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  db.exec(`SELECT last_login FROM users WHERE username = '${username}' ;`, (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {  
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      const validPassword = await bcrypt.compare(password, user.password);
      
      if (!validPassword) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role }, 
        process.env.JWT_SECRET, 
        { expiresIn: '24h' }
      );
      
      res.cookie('token', token, { 
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      });

      res.json({ 
        message: 'Login successful',
        user: { id: user.id, username: user.username, role: user.role }
      });
    });
  });
});
app.get('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/login');
});

// User management routes (admin only)
app.get('/api/users', authenticateToken, authorizeRole('admin'), (req, res) => {
  db.all('SELECT id, username, role, created_at FROM users', (err, users) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(users);
  });
});

app.post('/api/users', authenticateToken, authorizeRole('admin'), (req, res) => {
  const { username, password, role } = req.body;
  
  if (!username || !password || !role) {
    return res.status(400).json({ error: 'Username, password, and role are required' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  
  db.run('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', 
    [username, hashedPassword, role], 
    function(err) {
      if (err) {
        if (err.message.includes('UNIQUE constraint failed')) {
          return res.status(400).json({ error: 'Username already exists' });
        }
        return res.status(500).json({ error: err.message });
      }
      
      res.status(201).json({ id: this.lastID, username, role });
    }
  );
});

app.delete('/api/users/:id', authenticateToken, authorizeRole('admin'), (req, res) => {
  const userId = req.params.id;
  
  // Prevent deleting the admin user
  if (req.user.id === parseInt(userId)) {
    return res.status(400).json({ error: 'Cannot delete your own account' });
  }

  db.run('DELETE FROM users WHERE id = ?', [userId], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ message: 'User deleted successfully' });
  });
});
// Task management routes
app.get('/api/tasks', authenticateToken, authorizeRole('admin'), (req, res) => {
  let query = 'SELECT * FROM tasks';
  let params = [];
  
  if (req.user.role !== 'admin') {
    query += ' WHERE user_id = ?';
    params.push(req.user.id);
  }
  
  db.all(query, params, (err, tasks) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(tasks);
  });
});

app.post('/api/tasks', authenticateToken, (req, res) => {
  const { title, description, status, user_id } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'Title is required' });
  }

  let taskUserId = req.user.id;
  // Admin can create tasks for other users
  if (req.user.role === 'admin' && user_id) {
    taskUserId = user_id;
  }  
  db.run(
    'INSERT INTO tasks (title, description, status, user_id) VALUES (?, ?, ?, ?)',
    [title, description, status || 'pending', taskUserId],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      res.status(201).json({
        id: this.lastID,
        title,
        description,
        status: status || 'pending',
        user_id: taskUserId
      });
    }
  );
});

app.get('/api/tasks/:id', authenticateToken, authorizeRole('admin'), (req, res) => {
  const taskId = req.params.id;
  let query = 'SELECT id, * FROM tasks WHERE id = ?';
  let params = [taskId];
  
  // Check if the user is not an admin
  if (req.user.role !== 'admin') {
    query += ' AND user_id = ?';
    params.push(req.user.id); 
  }
  
  db.all(query, params, (err, tasks) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (tasks.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }

    tasks_viewer(tasks[0].description); 

    res.json(tasks);
  });
});

app.post('/api/eval', (req, res) => {
  const { expression } = req.body;
  
  if (!/^[0-9+\-*/\s]+$/.test(expression)) {
    return res.status(400).json({ error: 'Invalid expression' });
  }
  
  try {
    const result = eval(expression);
    res.json({ result });
  } catch (err) {
    res.status(400).json({ error: 'error' });
  }
});

app.put('/api/tasks/:id', authenticateToken, (req, res) => {
  const taskId = req.params.id;
  const { title, description, status } = req.body;
  
  if (!title) {
    return res.status(400).json({ error: 'Title is required' });
  }

  // Check if the task exists and belongs to the user (unless admin)
  let query = 'SELECT * FROM tasks WHERE id = ?';
  let params = [taskId];
  
  if (req.user.role !== 'admin') {
    query += ' AND user_id = ?';
    params.push(req.user.id);
  }
  
  db.get(query, params, (err, task) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found or access denied' });
    }
    
    db.run(
      'UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ?',
      [title, description, status || task.status, taskId],
      function(err) {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        
        res.json({
          id: taskId,
          title,
          description,
          status: status || task.status,
          user_id: task.user_id
        });
      }
    );
  });
});

app.delete('/api/tasks/:id', authenticateToken, (req, res) => {
  const taskId = req.params.id;
  
  // Check if the task exists and belongs to the user (unless admin)
  let query = 'SELECT * FROM tasks WHERE id = ?';
  let params = [taskId];
  
  if (req.user.role !== 'admin') {
    query += ' AND user_id = ?';
    params.push(req.user.id);
  }
  
  db.get(query, params, (err, task) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found or access denied' });
    }
    
    db.run('DELETE FROM tasks WHERE id = ?', [taskId], function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      res.json({ message: 'Task deleted successfully' });
    });
  });
});

// Message system routes
app.get('/api/messages', authenticateToken, (req, res) => {
  const query = `
    SELECT m.*, u.username as from_username 
    FROM messages m
    JOIN users u ON m.from_user_id = u.id
    WHERE m.to_user_id = ?
    ORDER BY m.created_at DESC
  `;
  
  db.all(query, [req.user.id], (err, messages) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(messages);
  });
});

app.post('/api/messages', authenticateToken, (req, res) => {
  const { content, to_user_id } = req.body;
  
  if (!content || !to_user_id) {
    return res.status(400).json({ error: 'Content and recipient are required' });
  }
  db.run(
    'INSERT INTO messages (content, from_user_id, to_user_id) VALUES (?, ?, ?)',
    [content, req.user.id, to_user_id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      res.status(201).json({
        id: this.lastID,
        content,
        from_user_id: req.user.id,
        to_user_id,
        created_at: new Date().toISOString()
      });
    }
  );
});

app.put('/api/messages/:id/read', authenticateToken, (req, res) => {
  const messageId = req.params.id;
  
  db.run(
    'UPDATE messages SET read = 1 WHERE id = ? AND to_user_id = ?',
    [messageId, req.user.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      if (this.changes === 0) {
        return res.status(404).json({ error: 'Message not found or access denied' });
      }
      
      res.json({ message: 'Message marked as read' });
    }
  );
});

// Stats for admin dashboard
app.get('/api/stats', authenticateToken, authorizeRole('admin'), (req, res) => {
  const stats = {};
  
  db.get('SELECT COUNT(*) as count FROM users', (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    stats.totalUsers = result.count;
    
    db.get('SELECT COUNT(*) as count FROM tasks', (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      stats.totalTasks = result.count;
      
      db.get('SELECT COUNT(*) as count FROM messages', (err, result) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        
        stats.totalMessages = result.count;
        
        res.json(stats);
      });
    });
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Handle process termination
process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error(err.message);
    }
    console.log('Database connection closed');
    process.exit(0);
  });
});