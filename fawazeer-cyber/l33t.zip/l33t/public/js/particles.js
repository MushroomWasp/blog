// Mystery Vibes Portal - Particles Animation
document.addEventListener('DOMContentLoaded', function() {
  const particlesContainer = document.getElementById('particles');
  
  // Configuration
  const particleCount = 50;
  const particleColors = ['#7e57c2', '#b085f5', '#4d2c91', '#ff4081'];
  const minSize = 2;
  const maxSize = 5;
  const minSpeed = 0.2;
  const maxSpeed = 0.8;
  
  // Create particles
  for (let i = 0; i < particleCount; i++) {
    createParticle();
  }
  
  function createParticle() {
    const particle = document.createElement('div');
    
    // Random properties
    const size = Math.random() * (maxSize - minSize) + minSize;
    const color = particleColors[Math.floor(Math.random() * particleColors.length)];
    const left = Math.random() * 100;
    const top = Math.random() * 100;
    const speed = Math.random() * (maxSpeed - minSpeed) + minSpeed;
    const delay = Math.random() * 5;
    const opacity = Math.random() * 0.5 + 0.3;
    
    // Apply styles
    particle.style.position = 'absolute';
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;
    particle.style.backgroundColor = color;
    particle.style.borderRadius = '50%';
    particle.style.left = `${left}%`;
    particle.style.top = `${top}%`;
    particle.style.opacity = opacity;
    particle.style.animation = `float ${5/speed}s ease-in-out infinite`;
    particle.style.animationDelay = `${delay}s`;
    particle.style.boxShadow = `0 0 ${size*2}px ${color}`;
    
    // Add to container
    particlesContainer.appendChild(particle);
  }
  
  // Add animation keyframes
  const style = document.createElement('style');
  style.innerHTML = `
    @keyframes float {
      0%, 100% {
        transform: translateY(0) translateX(0);
      }
      25% {
        transform: translateY(-20px) translateX(10px);
      }
      50% {
        transform: translateY(0) translateX(20px);
      }
      75% {
        transform: translateY(20px) translateX(10px);
      }
    }
  `;
  document.head.appendChild(style);
});