// Mystery Vibes Portal - Login Script
document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('login-form');
  const errorMessage = document.getElementById('error-message');
  
  loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Validate input
    if (!username || !password) {
      showError('Please enter both username and password');
      return;
    }
    
    // Clear previous errors
    hideError();
    
    // Show loading state
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in...';
    
    // Send login request
    fetch('/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        showError(data.error);
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      } else {
        // Login successful, redirect to dashboard
        window.location.href = '/dashboard';
      }
    })
    .catch(error => {
      showError('An error occurred. Please try again.');
      console.error('Login error:', error);
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    });
  });
  
  function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
  }
  
  function hideError() {
    errorMessage.textContent = '';
    errorMessage.classList.remove('show');
  }
});