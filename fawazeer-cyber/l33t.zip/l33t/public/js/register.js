// Mystery Vibes Portal - Register Script
document.addEventListener('DOMContentLoaded', function() {
  const registerForm = document.getElementById('register-form');
  const errorMessage = document.getElementById('error-message');
  
  registerForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // Validate input
    if (!username || !password || !confirmPassword) {
      showError('Please fill in all fields');
      return;
    }
    
    if (password !== confirmPassword) {
      showError('Passwords do not match');
      return;
    }
    
    if (password.length < 6) {
      showError('Password must be at least 6 characters long');
      return;
    }
    
    // Clear previous errors
    hideError();
    
    // Show loading state
    const submitBtn = registerForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating account...';
    
    // Send registration request
    fetch('/api/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        showError(data.error);
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      } else {
        // Registration successful, redirect to login
        window.location.href = '/login?registered=true';
      }
    })
    .catch(error => {
      showError('An error occurred. Please try again.');
      console.error('Registration error:', error);
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    });
  });
  
  function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
  }
  
  function hideError() {
    errorMessage.textContent = '';
    errorMessage.classList.remove('show');
  }
});