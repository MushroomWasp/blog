// Mystery Vibes Portal - Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Create mystery glow effects
    createMysteryGlows();
    
    // Load dashboard data
    loadDashboardData();
    
    // Set up navigation
    setupNavigation();
    
    // Set up modal handling
    setupModals();
    
    // Set up theme toggle
    setupThemeToggle();
    
    // Set up form submissions
    setupFormSubmissions();
    
    // Set up API functions
    setupAPIFunctions();
  });
  
  // Create mystery glow effects
  function createMysteryGlows() {
    const body = document.querySelector('.dashboard-body');
    const glowCount = 3;
    
    for (let i = 0; i < glowCount; i++) {
      const glow = document.createElement('div');
      glow.className = 'mystery-glow';
      glow.style.left = `${Math.random() * 100}%`;
      glow.style.top = `${Math.random() * 100}%`;
      glow.style.animationDelay = `${i * 2}s`;
      body.appendChild(glow);
    }
    
    // Move glows with mouse movement for interactive effect
    document.addEventListener('mousemove', function(e) {
      const glows = document.querySelectorAll('.mystery-glow');
      const mouseX = e.clientX;
      const mouseY = e.clientY;
      
      glows.forEach((glow, index) => {
        // Make each glow move slightly differently
        const factor = 0.05 - (index * 0.01);
        const offsetX = (mouseX - window.innerWidth / 2) * factor;
        const offsetY = (mouseY - window.innerHeight / 2) * factor;
        
        glow.style.transform = `translate(${offsetX}px, ${offsetY}px) scale(${1 + index * 0.2})`;
      });
    });
  }
  
  // Load dashboard data
  function loadDashboardData() {
    // Load stats for overview
    fetch('/api/stats')
      .then(response => response.json())
      .then(data => {
        animateCounter('total-users', data.totalUsers);
        animateCounter('total-tasks', data.totalTasks);
        animateCounter('total-messages', data.totalMessages);
        
        // Add some recent activities
        addRecentActivity('System Initialized', 'Just now', '🔐');
        addRecentActivity('New User Registered', '5 minutes ago', '👤');
        addRecentActivity('Task Completed', '15 minutes ago', '✅');
        addRecentActivity('System Update', '1 hour ago', '🔄');
      })
      .catch(error => {
        console.error('Error loading stats:', error);
        // Fallback data for demo
        animateCounter('total-users', 42);
        animateCounter('total-tasks', 156);
        animateCounter('total-messages', 89);
      });
  
    // Load users for user management
    fetch('/api/users')
      .then(response => response.json())
      .then(users => {
        const tableBody = document.getElementById('users-table-body');
        tableBody.innerHTML = '';
        
        users.forEach((user, index) => {
          const row = document.createElement('tr');
          row.style.animation = `floatUp 0.3s ease-out forwards ${0.1 + index * 0.05}s`;
          row.style.opacity = '0';
          row.innerHTML = `
            <td>${user.id}</td>
            <td>${user.username}</td>
            <td>${user.role}</td>
            <td>${new Date(user.created_at).toLocaleString()}</td>
            <td>
              <button class="btn edit-user" data-id="${user.id}">Edit</button>
              <button class="btn delete-user" data-id="${user.id}">Delete</button>
            </td>
          `;
          tableBody.appendChild(row);
        });
        
        // Set up edit and delete handlers
        setupUserActions();
      })
      .catch(error => {
        console.error('Error loading users:', error);
        // Add fallback data for demo
        const tableBody = document.getElementById('users-table-body');
        tableBody.innerHTML = `
          <tr style="animation: floatUp 0.3s ease-out forwards 0.1s; opacity: 0;">
            <td>1</td>
            <td>admin</td>
            <td>admin</td>
            <td>${new Date().toLocaleString()}</td>
            <td>
              <button class="btn edit-user" data-id="1">Edit</button>
              <button class="btn delete-user" data-id="1">Delete</button>
            </td>
          </tr>
          <tr style="animation: floatUp 0.3s ease-out forwards 0.15s; opacity: 0;">
            <td>2</td>
            <td>user1</td>
            <td>user</td>
            <td>${new Date().toLocaleString()}</td>
            <td>
              <button class="btn edit-user" data-id="2">Edit</button>
              <button class="btn delete-user" data-id="2">Delete</button>
            </td>
          </tr>
        `;
      });
  
    // Load tasks for task management
    fetch('/api/tasks')
      .then(response => response.json())
      .then(tasks => {
        const tableBody = document.getElementById('tasks-table-body');
        tableBody.innerHTML = '';
        
        tasks.forEach((task, index) => {
          const row = document.createElement('tr');
          row.style.animation = `floatUp 0.3s ease-out forwards ${0.1 + index * 0.05}s`;
          row.style.opacity = '0';
          row.innerHTML = `
            <td>${task.id}</td>
            <td>${task.title}</td>
            <td><span class="task-status ${task.status}">${task.status}</span></td>
            <td>${task.user_id || 'Unassigned'}</td>
            <td>${new Date(task.created_at).toLocaleString()}</td>
            <td>
              <button class="btn edit-task" data-id="${task.id}">Edit</button>
              <button class="btn delete-task" data-id="${task.id}">Delete</button>
            </td>
          `;
          tableBody.appendChild(row);
        });
        
        // Set up task actions
        setupTaskActions();
      })
      .catch(error => {
        console.error('Error loading tasks:', error);
        // Add fallback data for demo
        const tableBody = document.getElementById('tasks-table-body');
        tableBody.innerHTML = `
          <tr style="animation: floatUp 0.3s ease-out forwards 0.1s; opacity: 0;">
            <td>1</td>
            <td>Implement Authentication</td>
            <td><span class="task-status completed">completed</span></td>
            <td>admin</td>
            <td>${new Date().toLocaleString()}</td>
            <td>
              <button class="btn edit-task" data-id="1">Edit</button>
              <button class="btn delete-task" data-id="1">Delete</button>
            </td>
          </tr>
          <tr style="animation: floatUp 0.3s ease-out forwards 0.15s; opacity: 0;">
            <td>2</td>
            <td>Fix API Security Issues</td>
            <td><span class="task-status in-progress">in-progress</span></td>
            <td>admin</td>
            <td>${new Date().toLocaleString()}</td>
            <td>
              <button class="btn edit-task" data-id="2">Edit</button>
              <button class="btn delete-task" data-id="2">Delete</button>
            </td>
          </tr>
          <tr style="animation: floatUp 0.3s ease-out forwards 0.2s; opacity: 0;">
            <td>3</td>
            <td>Update Dashboard UI</td>
            <td><span class="task-status pending">pending</span></td>
            <td>user1</td>
            <td>${new Date().toLocaleString()}</td>
            <td>
              <button class="btn edit-task" data-id="3">Edit</button>
              <button class="btn delete-task" data-id="3">Delete</button>
            </td>
          </tr>
        `;
      });
  
    // Load messages
    fetch('/api/messages')
      .then(response => response.json())
      .then(messages => {
        const messageList = document.getElementById('message-list');
        messageList.innerHTML = '';
        
        messages.forEach((message, index) => {
          const messageItem = document.createElement('div');
          messageItem.className = `message-item ${message.read ? '' : 'unread'}`;
          messageItem.dataset.id = message.id;
          messageItem.style.animation = `floatUp 0.3s ease-out forwards ${0.1 + index * 0.05}s`;
          messageItem.style.opacity = '0';
          messageItem.innerHTML = `
            <div class="message-sender">${message.from_username}</div>
            <div class="message-preview">${message.content.substring(0, 30)}${message.content.length > 30 ? '...' : ''}</div>
            <div class="message-time">${new Date(message.created_at).toLocaleString()}</div>
          `;
          messageList.appendChild(messageItem);
          
          // Add click handler to view message
          messageItem.addEventListener('click', function() {
            viewMessage(message);
          });
        });
      })
      .catch(error => {
        console.error('Error loading messages:', error);
        // Add fallback data for demo
        const messageList = document.getElementById('message-list');
        messageList.innerHTML = `
          <div class="message-item unread" data-id="1" style="animation: floatUp 0.3s ease-out forwards 0.1s; opacity: 0;">
            <div class="message-sender">System</div>
            <div class="message-preview">Welcome to Mystery Vibes Portal!</div>
            <div class="message-time">${new Date().toLocaleString()}</div>
          </div>
          <div class="message-item" data-id="2" style="animation: floatUp 0.3s ease-out forwards 0.15s; opacity: 0;">
            <div class="message-sender">Admin</div>
            <div class="message-preview">Please check the new security proto...</div>
            <div class="message-time">${new Date().toLocaleString()}</div>
          </div>
        `;
        
        // Add click handler to view message
        document.querySelectorAll('.message-item').forEach(item => {
          item.addEventListener('click', function() {
            const id = this.dataset.id;
            const sender = this.querySelector('.message-sender').textContent;
            const preview = this.querySelector('.message-preview').textContent;
            const time = this.querySelector('.message-time').textContent;
            
            // Create a mock message object
            const message = {
              id,
              from_username: sender,
              content: id === "1" ? 
                "Welcome to Mystery Vibes Portal! This system allows you to manage users, tasks, and communications securely. Please explore the dashboard and let us know if you have any questions." :
                "Please check the new security protocols that have been implemented. All API endpoints now require proper authentication and authorization. Let me know if you encounter any issues.",
              created_at: new Date().toISOString()
            };
            
            viewMessage(message);
          });
        });
      });
  }
  
  // Animate counter for stats
  function animateCounter(elementId, targetValue) {
    const element = document.getElementById(elementId);
    const duration = 2000; // 2 seconds
    const startTime = performance.now();
    const startValue = 0;
    
    function updateCounter(currentTime) {
      const elapsedTime = currentTime - startTime;
      const progress = Math.min(elapsedTime / duration, 1);
      
      // Use easeOutExpo for smooth animation
      const easeOutExpo = 1 - Math.pow(2, -10 * progress);
      const currentValue = Math.floor(startValue + (targetValue - startValue) * easeOutExpo);
      
      element.textContent = currentValue;
      
      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      } else {
        element.textContent = targetValue;
      }
    }
    
    requestAnimationFrame(updateCounter);
  }
  
  // Add recent activity
  function addRecentActivity(title, time, icon) {
    const activityList = document.getElementById('activity-list');
    const activityItem = document.createElement('div');
    activityItem.className = 'activity-item';
    activityItem.style.opacity = '0';
    
    activityItem.innerHTML = `
      <div class="activity-icon">${icon}</div>
      <div class="activity-content">
        <div class="activity-title">${title}</div>
        <div class="activity-time">${time}</div>
      </div>
    `;
    
    activityList.appendChild(activityItem);
    
    // Trigger animation after a small delay
    setTimeout(() => {
      activityItem.style.animation = 'floatUp 0.4s ease-out forwards';
    }, 100 * activityList.children.length);
  }
  
  // Set up navigation
  function setupNavigation() {
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const section = this.getAttribute('data-section');
        
        // Hide all sections with animation
        document.querySelectorAll('.dashboard-section').forEach(section => {
          section.classList.remove('active');
        });
        
        // Show selected section
        const targetSection = document.getElementById(section);
        targetSection.classList.add('active');
        
        // Update active link
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
          link.classList.remove('active');
        });
        this.classList.add('active');
        
        // On mobile, hide sidebar after selection
        if (window.innerWidth < 992) {
          document.querySelector('.sidebar').classList.remove('show');
        }
      });
    });
    
    // Mobile menu toggle
    const menuToggle = document.createElement('button');
    menuToggle.className = 'menu-toggle btn icon-btn';
    menuToggle.innerHTML = '☰';
    menuToggle.style.position = 'fixed';
    menuToggle.style.top = '1rem';
    menuToggle.style.left = '1rem';
    menuToggle.style.zIndex = '20';
    menuToggle.style.display = 'none';
    
    document.body.appendChild(menuToggle);
    
    menuToggle.addEventListener('click', function() {
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Show/hide menu toggle based on screen size
    function handleResize() {
      if (window.innerWidth < 992) {
        menuToggle.style.display = 'flex';
      } else {
        menuToggle.style.display = 'none';
        document.querySelector('.sidebar').classList.remove('show');
      }
    }
    
    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check
  }
  
  // Set up modals
  function setupModals() {
    // Open modal function
    window.openModal = function(modalId) {
      const modal = document.getElementById(modalId);
      modal.style.display = 'flex';
      
      // Add animation class
      setTimeout(() => {
        modal.classList.add('show');
      }, 10);
      
      // Prevent body scrolling
      document.body.style.overflow = 'hidden';
    };
  
    // Close modal function
    window.closeModal = function(modalId) {
      const modal = document.getElementById(modalId);
      modal.classList.remove('show');
      
      // Wait for animation to complete before hiding
      setTimeout(() => {
        modal.style.display = 'none';
        document.body.style.overflow = '';
      }, 300);
    };
  
    // Set up close buttons
    document.querySelectorAll('.close-modal').forEach(button => {
      button.addEventListener('click', function() {
        const modal = this.closest('.modal');
        closeModal(modal.id);
      });
    });
  
    // Close modal when clicking outside content
    document.querySelectorAll('.modal').forEach(modal => {
      modal.addEventListener('click', function(e) {
        if (e.target === this) {
          closeModal(this.id);
        }
      });
    });
  
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal.show').forEach(modal => {
          closeModal(modal.id);
        });
      }
    });
  }
  
  // Set up theme toggle
  function setupThemeToggle() {
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.querySelector('.dashboard-body');
    
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('mystery-vibes-theme');
    if (savedTheme === 'dark') {
      body.classList.add('dark-mode');
      themeToggle.textContent = '☀️';
    } else {
      themeToggle.textContent = '🌙';
    }
    
    themeToggle.addEventListener('click', function() {
      body.classList.toggle('dark-mode');
      
      if (body.classList.contains('dark-mode')) {
        this.textContent = '☀️';
        localStorage.setItem('mystery-vibes-theme', 'dark');
      } else {
        this.textContent = '🌙';
        localStorage.setItem('mystery-vibes-theme', 'light');
      }
      
      // Add ripple effect
      const ripple = document.createElement('div');
      ripple.className = 'theme-ripple';
      ripple.style.position = 'fixed';
      ripple.style.top = '0';
      ripple.style.left = '0';
      ripple.style.width = '100%';
      ripple.style.height = '100%';
      ripple.style.backgroundColor = body.classList.contains('dark-mode') ? 'rgba(0,0,0,0.2)' : 'rgba(255,255,255,0.2)';
      ripple.style.opacity = '0';
      ripple.style.transition = 'opacity 0.5s ease';
      ripple.style.pointerEvents = 'none';
      ripple.style.zIndex = '999';
      
      document.body.appendChild(ripple);
      
      // Trigger animation
      setTimeout(() => {
        ripple.style.opacity = '1';
        
        setTimeout(() => {
          ripple.style.opacity = '0';
          
          setTimeout(() => {
            document.body.removeChild(ripple);
          }, 500);
        }, 300);
      }, 10);
    });
    
    // Theme settings in settings panel
    const themeSelect = document.getElementById('theme-select');
    const accentColor = document.getElementById('accent-color');
    const saveThemeBtn = document.getElementById('save-theme');
    
    // Set initial values
    themeSelect.value = savedTheme || 'light';
    
    // Get saved accent color
    const savedAccent = localStorage.getItem('mystery-vibes-accent');
    if (savedAccent) {
      accentColor.value = savedAccent;
      document.documentElement.style.setProperty('--accent-color', savedAccent);
    }
    
    saveThemeBtn.addEventListener('click', function() {
      // Save theme
      const selectedTheme = themeSelect.value;
      if (selectedTheme === 'dark') {
        body.classList.add('dark-mode');
        themeToggle.textContent = '☀️';
      } else {
        body.classList.remove('dark-mode');
        themeToggle.textContent = '🌙';
      }
      localStorage.setItem('mystery-vibes-theme', selectedTheme);
      
      // Save accent color
      const selectedAccent = accentColor.value;
      document.documentElement.style.setProperty('--accent-color', selectedAccent);
      localStorage.setItem('mystery-vibes-accent', selectedAccent);
      
      // Show success message
      showNotification('Theme settings saved successfully!', 'success');
    });
  }
  
  // Set up form submissions
  function setupFormSubmissions() {
    // User form
    const userForm = document.getElementById('user-form');
    userForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(this);
      const userData = {
        username: formData.get('username'),
        password: formData.get('password'),
        role: formData.get('role')
      };
      
      // Show loading state
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.textContent = 'Saving...';
      submitBtn.disabled = true;
      
      fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
      })
      .then(response => response.json())
      .then(data => {
        closeModal('user-modal');
        showNotification('User saved successfully!', 'success');
        
        // Reload user list
        loadDashboardData();
      })
      .catch(error => {
        console.error('Error creating user:', error);
        showNotification('Error saving user. Please try again.', 'error');
      })
      .finally(() => {
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
      });
    });
  
    // Task form
    const taskForm = document.getElementById('task-form');
    taskForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(this);
      const taskData = {
        title: formData.get('title'),
        description: formData.get('description'),
        status: formData.get('status'),
        user_id: formData.get('user_id') || null
      };
      
      // Show loading state
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.textContent = 'Saving...';
      submitBtn.disabled = true;
      
      fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(taskData)
      })
      .then(response => response.json())
      .then(data => {
        closeModal('task-modal');
        showNotification('Task saved successfully!', 'success');
        
        // Reload task list
        loadDashboardData();
      })
      .catch(error => {
        console.error('Error creating task:', error);
        showNotification('Error saving task. Please try again.', 'error');
      })
      .finally(() => {
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
      });
    });
  
    // Message form
    const messageForm = document.getElementById('message-form');
    messageForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(this);
      const messageData = {
        content: formData.get('content'),
        to_user_id: formData.get('to_user_id')
      };
      
      // Show loading state
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.textContent = 'Sending...';
      submitBtn.disabled = true;
      
      fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(messageData)
      })
      .then(response => response.json())
      .then(data => {
        closeModal('message-modal');
        showNotification('Message sent successfully!', 'success');
        
        // Reload message list
        loadDashboardData();
      })
      .catch(error => {
        console.error('Error sending message:', error);
        showNotification('Error sending message. Please try again.', 'error');
      })
      .finally(() => {
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
      });
    });
    
    // Password change form
    const changePasswordBtn = document.getElementById('change-password');
    changePasswordBtn.addEventListener('click', function() {
      const currentPassword = document.getElementById('current-password').value;
      const newPassword = document.getElementById('new-password').value;
      const confirmNewPassword = document.getElementById('confirm-new-password').value;
      
      if (!currentPassword || !newPassword || !confirmNewPassword) {
        showNotification('Please fill in all password fields.', 'error');
        return;
      }
      
      if (newPassword !== confirmNewPassword) {
        showNotification('New passwords do not match.', 'error');
        return;
      }
      
      // Show loading state
      const originalText = this.textContent;
      this.textContent = 'Changing...';
      this.disabled = true;
      
      // Simulate API call
      setTimeout(() => {
        showNotification('Password changed successfully!', 'success');
        
        // Reset fields
        document.getElementById('current-password').value = '';
        document.getElementById('new-password').value = '';
        document.getElementById('confirm-new-password').value = '';
        
        // Reset button state
        this.textContent = originalText;
        this.disabled = false;
      }, 1500);
    });
    
    // System settings form
    const saveSystemSettingsBtn = document.getElementById('save-system-settings');
    saveSystemSettingsBtn.addEventListener('click', function() {
      const notificationSetting = document.getElementById('notification-setting').value;
      const languageSetting = document.getElementById('language-setting').value;
      
      // Show loading state
      const originalText = this.textContent;
      this.textContent = 'Saving...';
      this.disabled = true;
      
      // Simulate API call
      setTimeout(() => {
        showNotification('System settings saved successfully!', 'success');
        
        // Save to localStorage
        localStorage.setItem('mystery-vibes-notifications', notificationSetting);
        localStorage.setItem('mystery-vibes-language', languageSetting);
        
        // Reset button state
        this.textContent = originalText;
        this.disabled = false;
      }, 1500);
    });
  }
  
  // Set up user actions
  function setupUserActions() {
    // Add user button
    document.getElementById('add-user-btn').addEventListener('click', function() {
      document.getElementById('user-modal-title').textContent = 'Add New User';
      document.getElementById('user-form').reset();
      openModal('user-modal');
    });
    
    // Edit user buttons
    document.querySelectorAll('.edit-user').forEach(button => {
      button.addEventListener('click', function() {
        const userId = this.dataset.id;
        document.getElementById('user-modal-title').textContent = 'Edit User';
        
        // In a real app, you would fetch the user data here
        // For demo, we'll just open the modal
        openModal('user-modal');
      });
    });
    
    // Delete user buttons
    document.querySelectorAll('.delete-user').forEach(button => {
      button.addEventListener('click', function() {
        const userId = this.dataset.id;
        
        if (confirm('Are you sure you want to delete this user?')) {
          // Show loading state
          const originalText = this.textContent;
          this.textContent = 'Deleting...';
          this.disabled = true;
          
          fetch(`/api/users/${userId}`, {
            method: 'DELETE'
          })
          .then(response => response.json())
          .then(data => {
            showNotification('User deleted successfully!', 'success');
            
            // Reload user list
            loadDashboardData();
          })
          .catch(error => {
            console.error('Error deleting user:', error);
            showNotification('Error deleting user. Please try again.', 'error');
            
            // Reset button state
            this.textContent = originalText;
            this.disabled = false;
          });
        }
      });
    });
  }
  
  // Set up task actions
  function setupTaskActions() {
    // Add task button
    document.getElementById('add-task-btn').addEventListener('click', function() {
      document.getElementById('task-modal-title').textContent = 'Add New Task';
      document.getElementById('task-form').reset();
      
      // Load users for assignment dropdown
      fetch('/api/users')
        .then(response => response.json())
        .then(users => {
          const select = document.getElementById('task-user');
          select.innerHTML = '<option value="">Unassigned</option>';
          
          users.forEach(user => {
            const option = document.createElement('option');
            option.value = user.id;
            option.textContent = user.username;
            select.appendChild(option);
          });
        })
        .catch(error => {
          console.error('Error loading users for task assignment:', error);
          // Add fallback options
          const select = document.getElementById('task-user');
          select.innerHTML = `
            <option value="">Unassigned</option>
            <option value="1">admin</option>
            <option value="2">user1</option>
          `;
        });
      
      openModal('task-modal');
    });
    
    // Task filter
    document.getElementById('task-filter').addEventListener('change', function() {
      const filter = this.value;
      const rows = document.querySelectorAll('#tasks-table-body tr');
      
      rows.forEach(row => {
        const statusCell = row.querySelector('td:nth-child(3)');
        const status = statusCell.textContent.trim().toLowerCase();
        
        if (filter === 'all' || status === filter) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });
    
    // Edit task buttons
    document.querySelectorAll('.edit-task').forEach(button => {
      button.addEventListener('click', function() {
        const taskId = this.dataset.id;
        document.getElementById('task-modal-title').textContent = 'Edit Task';
        
        // In a real app, you would fetch the task data here
        // For demo, we'll just open the modal
        openModal('task-modal');
      });
    });
    
    // Delete task buttons
    document.querySelectorAll('.delete-task').forEach(button => {
      button.addEventListener('click', function() {
        const taskId = this.dataset.id;
        
        if (confirm('Are you sure you want to delete this task?')) {
          // Show loading state
          const originalText = this.textContent;
          this.textContent = 'Deleting...';
          this.disabled = true;
          
          fetch(`/api/tasks/${taskId}`, {
            method: 'DELETE'
          })
          .then(response => response.json())
          .then(data => {
            showNotification('Task deleted successfully!', 'success');
            
            // Reload task list
            loadDashboardData();
          })
          .catch(error => {
            console.error('Error deleting task:', error);
            showNotification('Error deleting task. Please try again.', 'error');
            
            // Reset button state
            this.textContent = originalText;
            this.disabled = false;
          });
        }
      });
    });
  }
  
  // View message
  function viewMessage(message) {
    const messageContent = document.getElementById('message-content');
    
    // Mark as active in the list
    document.querySelectorAll('.message-item').forEach(item => {
      item.classList.remove('active');
      if (item.dataset.id === message.id.toString()) {
        item.classList.remove('unread');
        item.classList.add('active');
      }
    });
    
    // Display message content
    messageContent.innerHTML = `
      <div class="message-header" style="animation: fadeIn 0.3s ease-out;">
        <div class="message-subject">Message from ${message.from_username}</div>
        <div class="message-info">
          <span>${new Date(message.created_at).toLocaleString()}</span>
        </div>
      </div>
      <div class="message-body" style="animation: fadeIn 0.5s ease-out;">
        ${message.content}
      </div>
    `;
    
    // Mark as read in the database
    fetch(`/api/messages/${message.id}/read`, {
      method: 'PUT'
    }).catch(error => {
      console.error('Error marking message as read:', error);
    });
  }
  
  // Compose message
  document.getElementById('compose-message-btn').addEventListener('click', function() {
    document.getElementById('message-form').reset();
    
    // Load users for recipient dropdown
    fetch('/api/users')
      .then(response => response.json())
      .then(users => {
        const select = document.getElementById('message-recipient');
        select.innerHTML = '';
        
        users.forEach(user => {
          const option = document.createElement('option');
          option.value = user.id;
          option.textContent = user.username;
          select.appendChild(option);
        });
      })
      .catch(error => {
        console.error('Error loading users for message recipients:', error);
        // Add fallback options
        const select = document.getElementById('message-recipient');
        select.innerHTML = `
          <option value="1">admin</option>
          <option value="2">user1</option>
        `;
      });
    
    openModal('message-modal');
  });
  
  // Set up API functions
  function setupAPIFunctions() {
    // Calculator function
    document.getElementById('calculate-btn').addEventListener('click', function() {
      const expression = document.getElementById('calc-expression').value;
      const resultElement = document.getElementById('calc-result');
      
      if (!expression) {
        resultElement.innerHTML = `<div class="error">Please enter an expression</div>`;
        return;
      }
      
      // Show loading state
      resultElement.innerHTML = `<div>Calculating...</div>`;
      
      fetch('/api/eval', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ expression })
      })
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          resultElement.innerHTML = `<div class="error">${data.error}</div>`;
        } else {
          resultElement.innerHTML = `<div class="success">Result: ${data.result}</div>`;
          
          // Add a mystical effect
          const resultDiv = resultElement.querySelector('.success');
          resultDiv.style.animation = 'pulseGlow 2s';
        }
      })
      .catch(error => {
        resultElement.innerHTML = `<div class="error">Error: ${error.message}</div>`;
      });
    });
  
    // IP Wrapper function
    document.getElementById('wrap-ip-btn').addEventListener('click', function() {
      const interface = document.getElementById('interface-input').value;
      const resultElement = document.getElementById('wrap-result');
      
      if (!interface) {
        resultElement.innerHTML = `<div class="error">Please enter an interface name</div>`;
        return;
      }
      
      // Show loading state
      resultElement.innerHTML = `<div>Processing...</div>`;
      
      fetch('/api/wrapp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ interface })
      })
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          resultElement.innerHTML = `<div class="error">${data.error}</div>`;
        } else {
          resultElement.innerHTML = `<div class="success">Wrapped IP: ${data.wrapped}</div>`;
          
          // Add a mystical effect
          const resultDiv = resultElement.querySelector('.success');
          resultDiv.style.animation = 'pulseGlow 2s';
        }
      })
      .catch(error => {
        resultElement.innerHTML = `<div class="error">Error: ${error.message}</div>`;
      });
    });
  }
  
  // Show notification
  function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notificationContainer = document.querySelector('.notification-container');
    
    if (!notificationContainer) {
      notificationContainer = document.createElement('div');
      notificationContainer.className = 'notification-container';
      notificationContainer.style.position = 'fixed';
      notificationContainer.style.top = '20px';
      notificationContainer.style.right = '20px';
      notificationContainer.style.zIndex = '1000';
      notificationContainer.style.display = 'flex';
      notificationContainer.style.flexDirection = 'column';
      notificationContainer.style.gap = '10px';
      document.body.appendChild(notificationContainer);
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.padding = '12px 20px';
    notification.style.borderRadius = '8px';
    notification.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
    notification.style.display = 'flex';
    notification.style.alignItems = 'center';
    notification.style.gap = '10px';
    notification.style.minWidth = '300px';
    notification.style.maxWidth = '400px';
    notification.style.animation = 'slideInRight 0.3s ease-out forwards';
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(50px)';
    notification.style.backdropFilter = 'blur(10px)';
    notification.style.webkitBackdropFilter = 'blur(10px)';
    
    // Set background color based on type
    if (type === 'success') {
      notification.style.backgroundColor = 'rgba(80, 250, 123, 0.2)';
      notification.style.borderLeft = '4px solid var(--success)';
    } else if (type === 'error') {
      notification.style.backgroundColor = 'rgba(255, 85, 85, 0.2)';
      notification.style.borderLeft = '4px solid var(--danger)';
    } else {
      notification.style.backgroundColor = 'rgba(139, 233, 253, 0.2)';
      notification.style.borderLeft = '4px solid var(--info)';
    }
    
    // Add icon based on type
    let icon;
    if (type === 'success') {
      icon = '✅';
    } else if (type === 'error') {
      icon = '❌';
    } else {
      icon = 'ℹ️';
    }
    
    notification.innerHTML = `
      <div style="font-size: 1.2rem;">${icon}</div>
      <div style="flex: 1;">${message}</div>
      <div class="close-notification" style="cursor: pointer; font-size: 1rem;">×</div>
    `;
    
    notificationContainer.appendChild(notification);
    
    // Add close handler
    notification.querySelector('.close-notification').addEventListener('click', function() {
      closeNotification(notification);
    });
    
    // Auto close after 5 seconds
    setTimeout(() => {
      closeNotification(notification);
    }, 5000);
  }
  
  // Close notification
  function closeNotification(notification) {
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(50px)';
    
    setTimeout(() => {
      notification.remove();
    }, 300);
  }