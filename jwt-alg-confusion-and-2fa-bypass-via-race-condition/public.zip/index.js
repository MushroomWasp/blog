const express = require("express");

const crypto = require("node:crypto");
const fs = require("fs");
const cookieParser = require("cookie-parser");
const { signJWT, decodeJWT } = require("./lib/customcrypto");

const FLAG = process.env.FLAG ?? "flag{redacted}";
const app = express();

app.use(express.json());
app.use(cookieParser());

const PrivateKey = "REDACTED!!!!!!";
const PublicKey =
  "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEyMbEOh9WDHgfi4JM6qbYbGnOddHNq2OyPwR4Oe4GlHd3Qmuaim/9DRpEvqKhIzNlspSv59vgm79AEIJ5QvNlCQ==";

app.set("view engine", "ejs");

Object.freeze(Object.prototype);

let database = {
  admin: {
    id: "83170defdfedaebff2ca739d725294c7", // Same as deployment
    username: "Admin",
    password: crypto.randomBytes(32).toString("hex"),
    isEmailVerified: true,
    emailServiceURL: "http://localhost:5000/mail",
  },
};

let keyStorage = crypto.randomBytes(10).toString("hex");

const GenerateRandomStringSecurely = () => {
  return new Promise((resolve, _) => {
    let data = "";
    for (var index = 0; index < 15000; index++)
      data += crypto.randomBytes(1000).toString("hex")[0];
    const hash = crypto.createHash("sha512").update(data);
    let finalHash = hash.digest("hex");
    resolve(finalHash.slice(0, 16));
  });
};

app.get("/", (_, res) => {
  res.redirect("/login");
});

app.get("/login", (_, res) => {
  res.render("login");
});

app.get("/register", (_, res) => {
  res.render("register");
});

app.get("/2fa", async (req, res) => {
  const token = req.cookies.session ?? "";

  let decodedToken = "";
  try {
    decodedToken = await decodeJWT(token, PublicKey);
  } catch (e) {
    res.json({ message: "Error: Unauthorized" });
    return;
  }

  return res.render("2fa");
});

app.get("/validate", async (req, res) => {
  const token = req.cookies.session ?? "";

  let decodedToken = "";
  try {
    decodedToken = await decodeJWT(token, PublicKey);
  } catch (e) {
    res.json({ message: "Error: Unauthorized" });
    return;
  }
  res.render("validate");
});

app.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!Object.keys(database).includes(username)) {
      res.json({ message: "Error: Invalid Username" });
      return;
    }

    if (database[username]["password"] == password) {
      let token = await signJWT("ES256", database[username]["id"], PrivateKey);

      res
        .cookie(
          "session",
          token,
          {
            maxAge: 30000,
          },
          { algorithm: "HS256" },
        )
        .json({ message: "Sucessful login" });
      return;
    } else {
      res.json({ message: "Invalid password" });
      return;
    }
  } catch (e) {
    res.json({ message: "Failure" });
  }
});

app.post("/register", async (req, res) => {
  try {
    const data = req.body.data;
    const username = data.username;

    const whitelist = [
      "username",
      "password",
      "isEmailVerified",
      "emailServiceURL",
    ];

    if (
      username.toLowerCase() == "admin" ||
      Object.keys(database).includes(username)
    ) {
      res.json({ message: "unallowed key" });
      return;
    }

    database[username] = {};

    for (const key of Object.keys(data)) {
      if (whitelist.indexOf(key) != -1) {
        database[username][key] = data[key];
      }
    }

    database[username]["id"] = crypto.randomBytes(16).toString("hex");

    res.json({ message: "Registeration Success" });
  } catch (e) {
    res.json({ message: "Registeration Failed" });
  }
});

app.post("/2fa", async (req, res) => {
  const token = req.cookies.session ?? "";

  let decodedToken = "";
  try {
    decodedToken = await decodeJWT(token, PublicKey);
  } catch (e) {
    res.json({ message: "Error: Unauthorized" });
    return;
  }

  if (database.admin.id != decodedToken.id) {
    res.json({ message: "no permission" });
    return;
  }
  const keyStorageFile = await fs.promises.open(keyStorage, "w");
  let newKey = await GenerateRandomStringSecurely();

  if (new URL(database.admin.emailServiceURL).hostname !== "localhost") {
    res.json({ message: "Email Service validation failed" });
    return;
  }
  await fetch(database.admin.emailServiceURL, {
    method: "POST",
    body: JSON.stringify({
      "2fa_code": newKey,
    }),
    headers: { "Content-Type": "application/json" },
  });
  await keyStorageFile.write(newKey);
  await keyStorageFile.close();
  res.json({ message: "2FA Code is Sent" });
  return;
});

app.post("/validate", async (req, res) => {
  const token = req.cookies.session ?? "";
  let data = "";
  try {
    data = await decodeJWT(token, PublicKey);
  } catch (e) {
    res.json({ message: "Error: Unauthorized" });
    return;
  }

  if (database.admin.id != data.id) {
    res.json({ message: "Error: Missing permissions" });
    return;
  }
  try {
    const { data } = req.body;
    const key = await fs.promises.readFile(keyStorage);

    await fs.promises.unlink(keyStorage);

    keyStorage = crypto.randomBytes(10).toString("hex");

    if (data == key) {
      res.json({ flag: FLAG });
      return;
    } else {
      res.json({ message: "Error: Invalid token" });
      return;
    }
  } catch (e) {
    res.json({ message: "Internal Error" });
    return;
  }
});

/*
Internal Mail service
*/

app.use(express.urlencoded({ extended: true }));

app.listen(4000, () => {
  console.log("Server listening on http://localhost:4000");
});

const app2 = express();

app2.use(express.json());

function receive_sso_key_from_mail(key) {
  console.log(key);
}

app2.post("/mail", async (req, res) => {
  const key = req.body.auth_key;
  if (key) {
    receive_sso_key_from_mail(key);
    res.status(200);
    res.send("received!");
    return;
  } else {
    res.status(400);
    res.send("failure");
    return;
  }
});

app2.listen(5000);
