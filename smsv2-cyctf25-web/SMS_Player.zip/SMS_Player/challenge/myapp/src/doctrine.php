<?php

require_once '/var/www/html/vendor/autoload.php';

use Doctrine\DBAL\DriverManager;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\ORMSetup;

$dbParams = [
    'driver'   => 'pdo_mysql',
    'host'     => 'db',
    'dbname'   => 'ict',
    'user'     => 'ict',
    'password' => 'db_pass',
    'charset'  => 'utf8'
];

$config = ORMSetup::createAttributeMetadataConfiguration(
    paths: [__DIR__ . '/Entity'],
    isDevMode: true,
);



$entityManager = EntityManager::create($dbParams, $config);

function getEntityManager(): EntityManager
{
    global $entityManager;
    return $entityManager;
}

function findUser($id)
{
    return getEntityManager()->getRepository(\App\Entity\User::class)->find($id);
}

function findUserByUsername($username)
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\User::class, 'u')
        ->where('u.username = :username')
        ->setParameter('username', $username);

    try {
        return $qb->getQuery()->getOneOrNullResult();
    } catch (\Exception $e) {
        return null;
    }
}

function getUserByUsername($username)
{
    return findUserByUsername($username);
}

function findUserByApiKey($apiKey)
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\User::class, 'u')
        ->where('u.apiKey = :apiKey')
        ->setParameter('apiKey', $apiKey);

    try {
        return $qb->getQuery()->getOneOrNullResult();
    } catch (\Exception $e) {
        return null;
    }
}

function updateUser($user)
{
    getEntityManager()->persist($user);
    getEntityManager()->flush();
    return $user;
}

function authenticateUser($username, $password)
{
    $user = findUserByUsername($username);
    
    if ($user && $user->verifyPassword($password)) {
        return $user;
    }
    
    return null;
}

function createUser($attributes)
{
    $user = new \App\Entity\User();
    $user->setUsername($attributes['username']);
    $user->setPassword($attributes['password']);
    
    if (isset($attributes['role'])) {
        $user->setRole($attributes['role']);
    }
    
    getEntityManager()->persist($user);
    getEntityManager()->flush();
    
    return $user;
}

function getAllUsers()
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\User::class, 'u')
        ->orderBy('u.username', 'ASC');

    try {
        return $qb->getQuery()->getResult();
    } catch (\Exception $e) {
        return [];
    }
}

function findUpload($id)
{
    return getEntityManager()->getRepository(\App\Entity\Upload::class)->find($id);
}

function findUploadsByUserHash($userHash)
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\Upload::class, 'u')
        ->where('u.userHash = :userHash')
        ->setParameter('userHash', $userHash)
        ->orderBy('u.uploadedAt', 'DESC');

    try {
        return $qb->getQuery()->getResult();
    } catch (\Exception $e) {
        return [];
    }
}

function createUpload($attributes)
{
    $upload = new \App\Entity\Upload();
    $upload->setFileName($attributes['file_name']);
    $upload->setUserHash($attributes['user_hash']);
    $upload->setCalculatedHash($attributes['calculated_hash']);
    
    getEntityManager()->persist($upload);
    getEntityManager()->flush();
    
    return $upload;
}

function getAllUploads()
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\Upload::class, 'u')
        ->orderBy('u.uploadedAt', 'DESC');

    try {
        return $qb->getQuery()->getResult();
    } catch (\Exception $e) {
        return [];
    }
}

function findFeedback($id)
{
    return getEntityManager()->getRepository(\App\Entity\Feedback::class)->find($id);
}

function findFeedbackById($id)
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('f')
        ->from(\App\Entity\Feedback::class, 'f')
        ->where("f.id = " .$id)
        ->orderBy('f.createdAt', 'DESC');

    try {
        return $qb->getQuery()->getResult();
    } catch (\Exception $e) {
        return [];
    }
}

function createFeedback($attributes)
{
    $feedback = new \App\Entity\Feedback();
    $feedback->setUsername(htmlspecialchars($attributes['username']));
    $encodedFeedback = htmlspecialchars($attributes['feedback']);
    $feedback->setFeedback($encodedFeedback);
    
    getEntityManager()->persist($feedback);
    getEntityManager()->flush();
    
    return $feedback;
}

function getAllFeedback()
{
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('f')
        ->from(\App\Entity\Feedback::class, 'f')
        ->orderBy('f.createdAt', 'DESC');

    try {
        return $qb->getQuery()->getResult();
    } catch (\Exception $e) {
        return [];
    }
} 