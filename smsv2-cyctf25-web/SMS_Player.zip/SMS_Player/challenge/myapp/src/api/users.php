<?php

require_once __DIR__ . '/../api_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendErrorResponse('Method not allowed', 405);
}

try {
    $user = requireApiAuth();
    
    $limit = min((int)($_GET['limit'] ?? 50), 100);
    $offset = max((int)($_GET['offset'] ?? 0), 0);
    $role = $_GET['role'] ?? null;
    $search = $_GET['search'] ?? null;
    
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\User::class, 'u');
    
    if ($role) {
        $qb->andWhere('u.role = :role')
            ->setParameter('role', $role);
    }
    
    if ($search) {
        $qb->andWhere('u.username LIKE :search')
            ->setParameter('search', '%' . $search . '%');
    }
    
    $qb->orderBy('u.username', 'ASC')
        ->setMaxResults($limit)
        ->setFirstResult($offset);
    
    $users = $qb->getQuery()->getResult();
    
    $usersArray = array_map(function($u) {
        return [
            'id' => $u->getId(),
            'username' => $u->getUsername(),
            'role' => $u->getRole(),
            'has_api_key' => !empty($u->getApiKey())
        ];
    }, $users);
    
    $countQb = getEntityManager()->createQueryBuilder();
    $countQb->select('COUNT(u.id)')
        ->from(\App\Entity\User::class, 'u');
    
    if ($role) {
        $countQb->andWhere('u.role = :role')
            ->setParameter('role', $role);
    }
    
    if ($search) {
        $countQb->andWhere('u.username LIKE :search')
            ->setParameter('search', '%' . $search . '%');
    }
    
    $totalCount = $countQb->getQuery()->getSingleScalarResult();
    
    $response = [
        'users' => $usersArray,
        'pagination' => [
            'total' => (int)$totalCount,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + $limit) < $totalCount
        ]
    ];
    
    sendJsonResponse($response);
    
} catch (Exception $e) {
    sendErrorResponse('Internal server error: ' . $e->getMessage(), 500);
} 