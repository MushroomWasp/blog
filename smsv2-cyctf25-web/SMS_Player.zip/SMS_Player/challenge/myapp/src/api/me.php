<?php

session_start();
require_once __DIR__ . '/../api_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendErrorResponse('Method not allowed', 405);
}

try {
    $user = requireSessionAuth();
    
    if (!$user->getApiKey()) {
        $user->generateApiKey();
        updateUser($user);
    }
    
    $response = [
        'id' => $user->getId(),
        'username' => $user->getUsername(),
        'role' => $user->getRole(),
        'api_key' => $user->getApiKey()
    ];
    
    sendJsonResponse($response);
    
} catch (Exception $e) {
    sendErrorResponse('Internal server error: ' . $e->getMessage(), 500);
} 