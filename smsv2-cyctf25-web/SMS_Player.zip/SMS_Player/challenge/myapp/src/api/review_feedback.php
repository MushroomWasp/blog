<?php

require_once __DIR__ . '/../api_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendErrorResponse('Method not allowed', 405);
}

try {
    $user = requireApiAuth();
    
    $feedbackId = $_GET['feedback_id'] ?? null;
    
    if (!$feedbackId) {
        sendErrorResponse('Feedback ID is required', 400);
    }
    
    $feedback = findFeedback($feedbackId);
    
    if (!$feedback) {
        sendErrorResponse('Feedback not found', 404);
    }
    
    $response = $feedback->toArray();
    
    sendJsonResponse($response);
    
} catch (Exception $e) {
    sendErrorResponse('Internal server error: ' . $e->getMessage(), 500);
} 