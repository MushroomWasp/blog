<?php

require_once __DIR__ . '/../api_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendErrorResponse('Method not allowed', 405);
}

try {
    $user = requireApiAuth();
    
    $limit = min((int)($_GET['limit'] ?? 50), 100);
    $offset = max((int)($_GET['offset'] ?? 0), 0);
    $userHash = $_GET['user_hash'] ?? null;
    
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('u')
        ->from(\App\Entity\Upload::class, 'u');
    
    if ($userHash) {
        $qb->where('u.userHash = :userHash')
            ->setParameter('userHash', $userHash);
    }
    
    $qb->orderBy('u.uploadedAt', 'DESC')
        ->setMaxResults($limit)
        ->setFirstResult($offset);
    
    $uploads = $qb->getQuery()->getResult();
    
    $uploadsArray = array_map(function($u) {
        return $u->toArray();
    }, $uploads);
    
    $countQb = getEntityManager()->createQueryBuilder();
    $countQb->select('COUNT(u.id)')
        ->from(\App\Entity\Upload::class, 'u');
    
    if ($userHash) {
        $countQb->where('u.userHash = :userHash')
            ->setParameter('userHash', $userHash);
    }
    
    $totalCount = $countQb->getQuery()->getSingleScalarResult();
    
    $response = [
        'uploads' => $uploadsArray,
        'pagination' => [
            'total' => (int)$totalCount,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + $limit) < $totalCount
        ]
    ];
    
    sendJsonResponse($response);
    
} catch (Exception $e) {
    sendErrorResponse('Internal server error: ' . $e->getMessage(), 500);
} 