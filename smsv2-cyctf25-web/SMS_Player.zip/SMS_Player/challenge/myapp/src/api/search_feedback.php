<?php

require_once __DIR__ . '/../api_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendErrorResponse('Method not allowed', 405);
}

try {
    $user = requireApiAuth();
    
    $search = $_GET['search'] ?? '';
    $id = $_GET['feedback_id'] ?? null;
    $limit = min((int)($_GET['limit'] ?? 50), 100); 
    $offset = max((int)($_GET['offset'] ?? 0), 0);
    
    $qb = getEntityManager()->createQueryBuilder();
    $qb->select('f')
        ->from(\App\Entity\Feedback::class, 'f');
    
    if ($id !== null ) {
        $feedback = findFeedbackById($id);
        $feedbackArray = array_map(function($f) {
            return $f->toArray();
        }, $feedback);
        
        $response = [
            'feedback' => $feedbackArray,
            'pagination' => [
                'total' => count($feedbackArray),
                'limit' => $limit,
                'offset' => 0,
                'has_more' => false
            ]
        ];
        
        sendJsonResponse($response);
        return;
    }
    elseif (!empty($search)) {
        $qb->where('f.username LIKE :search OR f.feedback LIKE :search')
            ->setParameter('search', '%' . $search . '%');
    }
    
    $qb->orderBy('f.createdAt', 'DESC')
        ->setMaxResults($limit)
        ->setFirstResult($offset);
    
    $feedback = $qb->getQuery()->getResult();
    
    $feedbackArray = array_map(function($f) {
        return $f->toArray();
    }, $feedback);
    
    $countQb = getEntityManager()->createQueryBuilder();
    $countQb->select('COUNT(f.id)')
        ->from(\App\Entity\Feedback::class, 'f');
    
    if (!empty($search)) {
        $countQb->where('f.username LIKE :search OR f.feedback LIKE :search')
            ->setParameter('search', '%' . $search . '%');
    }
    
    $totalCount = $countQb->getQuery()->getSingleScalarResult();
    
    $response = [
        'feedback' => $feedbackArray,
        'pagination' => [
            'total' => (int)$totalCount,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + $limit) < $totalCount
        ]
    ];
    
    sendJsonResponse($response);
    
} catch (Exception $e) {
    sendErrorResponse('Internal server error: ' . $e->getMessage(), 500);
} 