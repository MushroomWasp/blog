<?php
include 'db.php';

session_start();

if (!isset($_SESSION['username'])) {
	header('Location: login.php');
	die();
}

$is_admin = isset($_SESSION['admin']) && $_SESSION['admin'];

$username = $_SESSION['username'];

$uploadModels = getAllUploads();
$uploads = array_map(function($upload) {
    return $upload->toArray();
}, $uploadModels);

require_once '/var/www/html/vendor/autoload.php';

$loader = new \Twig\Loader\ArrayLoader([
    'welcome' => "Welcome back, {{ username |raw }} !"
]);
$twig = new \Twig\Environment($loader);

$welcome_message = $twig->render('welcome', ['username' => $username]);
?>

<?php include 'header.php'; ?>

<!-- Dashboard Header -->
<div class="hero-section fade-in">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1><i class="fas fa-tachometer-alt"></i> <?php echo $is_admin ? 'Admin Dashboard' : 'User Dashboard'; ?></h1>
                <p class="lead"><?php echo $welcome_message; ?></p>
            </div>
            <div class="col-md-4 text-end">
                <a href="index.php" class="btn btn-outline-light me-2">
                    <i class="fas fa-home"></i> Home
                </a>
                <?php if ($is_admin): ?>
                <a href="review_feedback.php" class="btn btn-info me-2">
                    <i class="fas fa-comments"></i> Feedback Admin
                </a>
                <?php endif; ?>
                <a href="update.php" class="btn btn-warning me-2">
                    <i class="fas fa-key"></i> Change Password
                </a>
                <a href="logout.php" class="btn btn-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>
</div>

<?php if ($is_admin): ?>
<!-- Dashboard Content for Admin -->
<div class="container mt-4">
    <h2>Uploads</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>File Name</th>
                <th>User Hash</th>
                <th>Uploaded At</th>
                <th>Calculated Hash</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($uploads as $upload): ?>
                <tr>
                    <td><?php echo htmlspecialchars($upload['id']); ?></td>
                    <td><?php echo htmlspecialchars($upload['file_name']); ?></td>
                    <td><?php echo htmlspecialchars($upload['user_hash']); ?></td>
                    <td><?php echo htmlspecialchars($upload['uploaded_at']); ?></td>
                    <td><?php echo htmlspecialchars($upload['calculated_hash']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php else: ?>
<div class="container mt-4">
    <p>You can update your password using the button above.</p>
</div>
<?php endif; ?>

<script>
    function fetchFeedback() {
        fetch('feedback.php') 
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); 
            })
            .then(data => {
                const feedbackList = document.getElementById('feedback-list');
                
                if (data.length === 0) {
                    feedbackList.innerHTML = `
                        <div class="text-center text-muted">
                            <i class="fas fa-inbox"></i> No feedback submitted yet
                        </div>
                    `;
                    return;
                }
                
                feedbackList.innerHTML = '';
                
                data.forEach((feedback, index) => {
                    const feedbackCard = document.createElement('div');
                    feedbackCard.className = 'feedback-message mb-3';
                    feedbackCard.style.borderLeft = '5px solid #667eea';
                    feedbackCard.innerHTML = `
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <p class="mb-2"><strong>${feedback.username}</strong></p>
                                <p class="mb-0">${feedback.feedback}</p>
                            </div>
                            <div class="form-check ms-3">
                                <input class="form-check-input" type="checkbox" id="feedback-${index}">
                                <label class="form-check-label" for="feedback-${index}">
                                    <i class="fas fa-check"></i>
                                </label>
                            </div>
                        </div>
                    `;
                    feedbackList.appendChild(feedbackCard);
                });
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
                document.getElementById('feedback-list').innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> Error loading feedback
                    </div>
                `;
            });
    }

    document.addEventListener('DOMContentLoaded', fetchFeedback);
</script>

<?php include 'footer.php'; ?>

