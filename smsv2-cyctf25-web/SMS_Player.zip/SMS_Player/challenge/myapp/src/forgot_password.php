<?php
include 'db.php'; 
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];

    $user = findUserByUsername($username);

    if ($user) {
        $reset_code = bin2hex(random_bytes(32)); 
        $user->setVerificationCode($reset_code);

        try {
            $entityManager = getEntityManager();
            $entityManager->persist($user);
            $entityManager->flush();
            
            $_SESSION['reset_user'] = $username;
            header('Location: reset.php');
            exit();
        } catch (\Exception $e) {
            $error_message = "Failed to generate reset code. Please try again later.";
        }
    } else {
        $error_message = "The username you entered does not exist.";
    }
}
?>

<?php include 'header.php'; ?>

<div class="hero-section fade-in">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="form-card">
                    <div class="text-center mb-4">
                        <h1><i class="fas fa-key"></i> Forgot Password</h1>
                        <p class="lead">Enter your username to reset your password.</p>
                    </div>
                    
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form action="forgot_password.php" method="POST">
                        <div class="form-group">
                            <label for="username"><i class="fas fa-user"></i> Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-paper-plane"></i> Send Reset Link
                            </button>
                        </div>
                    </form>
                    
                    <div class="text-center mt-4">
                        <a href="login.php" class="text-decoration-none">
                            <i class="fas fa-arrow-left"></i> Back to Login
                        </a>
                    </div>
                    
                    <div class="text-center mt-3">
                        <a href="index.php" class="text-decoration-none">
                            <i class="fas fa-home"></i> Back to Home
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
