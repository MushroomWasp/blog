<?php
include 'db.php'; 
require('Captcha.php');
use Phppot\Captcha;

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $captcha = new Captcha();
    if (!$captcha->validateCaptcha($_POST['captcha'])) {
        $_SESSION['error'] = "CAPTCHA verification failed. Please try again.";
        header('Location: index.php');
        exit();
    }

    if (isset($_POST['username']) && isset($_POST['feedback'])) {
        $username = htmlspecialchars(trim($_POST['username']));
        $feedback = htmlspecialchars(trim($_POST['feedback']));
        
        if (empty($username) || empty($feedback)) {
            $_SESSION['error'] = "Both username and feedback are required.";
            header('Location: index.php');
            exit();
        }
        
        try {
            $feedbackEntity = new \App\Entity\Feedback();
            $feedbackEntity->setUsername($username);
            $feedbackEntity->setFeedback($feedback);
            
            $entityManager = getEntityManager();
            $entityManager->persist($feedbackEntity);
            $entityManager->flush();
            
            $_SESSION['success'] = "Thank you! Your feedback has been submitted successfully.";
            header('Location: index.php');
            exit();
        } catch (Exception $e) {
            $_SESSION['error'] = "An error occurred while submitting your feedback: " . $e->getMessage();
            header('Location: index.php');
            exit();
        }
    } else {
        $_SESSION['error'] = "Both username and feedback are required.";
        header('Location: index.php');
        exit();
    }
} else {
    header('Location: index.php');
    exit();
}
?>
