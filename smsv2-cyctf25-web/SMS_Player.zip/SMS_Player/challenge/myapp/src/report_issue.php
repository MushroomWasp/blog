<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = trim($_POST['url'] ?? '');
    
    if (empty($url)) {
        $_SESSION['error'] = "Please enter a valid URL.";
    } else {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            $_SESSION['error'] = "Please enter a valid URL format (e.g., http://example.com).";
        } elseif (!preg_match('/^https?:\/\//', $url)) {
            $_SESSION['error'] = "URL must start with http:// or https://";
        } else {
            $botUrl = 'http://bot:3000/visit';
            $data = ['url' => $url];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $botUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Content-Length: ' . strlen(json_encode($data))
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            
            if ($curlError) {
                $_SESSION['error'] = "Error connecting to bot: " . $curlError;
            } elseif ($httpCode >= 200 && $httpCode < 300) {
                $_SESSION['success'] = "URL submitted successfully! The bot has been notified to visit the url";
            } else {
                $_SESSION['error'] = "Bot returned error code: " . $httpCode . ". Please try again later.";
            }
        }
    }
    
    header('Location: report_issue.php');
    exit();
}
?>

<?php include 'header.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Hero Section -->
            <div class="hero-section text-center fade-in">
                <h1><i class="fas fa-bug me-3"></i>Report Issue</h1>
                <p class="lead">Submit URLs for our automated bot to investigate and resolve issues</p>
            </div>

            <!-- Alert Messages -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show fade-in" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo $_SESSION['success']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show fade-in" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?php echo $_SESSION['error']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <!-- Report Issue Form -->
            <div class="feedback-section slide-in-left">
                <div class="form-card">
                    <h2 class="text-center mb-4">
                        <i class="fas fa-paper-plane me-2"></i>Submit URL for Investigation
                    </h2>
                    
                    <form method="POST" action="report_issue.php">
                        <div class="form-group">
                            <label for="url" class="form-label">
                                <i class="fas fa-link me-2"></i>URL to Report
                            </label>
                            <input 
                                type="url" 
                                class="form-control" 
                                id="url" 
                                name="url" 
                                placeholder="https://example.com/issue-page"
                                required
                                pattern="https?://.+"
                                title="Please enter a valid URL starting with http:// or https://"
                            >
                            <div class="form-text">
                                <i class="fas fa-info-circle me-1"></i>
                                Enter the full URL including http:// or https://
                            </div>
                        </div>
                        
                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-send me-2"></i>Submit to Bot
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Information Section -->
            <div class="competition-section mt-5 slide-in-right">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2><i class="fas fa-robot me-2"></i>How It Works</h2>
                        <div class="motivational-description">
                            <p>Our automated bot will visit the URL you submit and analyze it for potential issues. 
                            This helps us identify and resolve problems quickly and efficiently.</p>
                            
                            <div class="row mt-4">
                                <div class="col-md-4 text-center">
                                    <i class="fas fa-search fa-2x mb-2"></i>
                                    <h5>Analysis</h5>
                                    <small>Bot examines the page content and structure</small>
                                </div>
                                <div class="col-md-4 text-center">
                                    <i class="fas fa-chart-line fa-2x mb-2"></i>
                                    <h5>Monitoring</h5>
                                    <small>Continuous monitoring for issues</small>
                                </div>
                                <div class="col-md-4 text-center">
                                    <i class="fas fa-tools fa-2x mb-2"></i>
                                    <h5>Resolution</h5>
                                    <small>Automated fixes when possible</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <i class="fas fa-shield-alt fa-5x mb-3"></i>
                        <h4>Secure & Reliable</h4>
                        <p class="small">Your submissions are processed securely</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 