<?php

namespace Models;

use App\Entity\Upload as UploadEntity;

class Upload
{
    private UploadEntity $entity;
    private array $attributes;

    public function __construct(array $attributes = [])
    {
        $this->attributes = $attributes;
        $this->entity = new UploadEntity();
        
        if (isset($attributes['file_name'])) {
            $this->entity->setFileName($attributes['file_name']);
        }
        if (isset($attributes['user_hash'])) {
            $this->entity->setUserHash($attributes['user_hash']);
        }
        if (isset($attributes['calculated_hash'])) {
            $this->entity->setCalculatedHash($attributes['calculated_hash']);
        }
    }

    public function save(): bool
    {
        try {
            $entityManager = \getEntityManager();
            $entityManager->persist($this->entity);
            $entityManager->flush();
            return true;
        } catch (\Exception $e) {
            error_log("Error saving upload: " . $e->getMessage());
            return false;
        }
    }

    public function getEntity(): UploadEntity
    {
        return $this->entity;
    }
} 