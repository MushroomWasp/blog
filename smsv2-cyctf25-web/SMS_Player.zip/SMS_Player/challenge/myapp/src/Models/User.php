<?php

namespace Models;

use App\Entity\User as UserEntity;

class User
{
    private UserEntity $entity;
    private array $attributes;

    public function __construct(array $attributes = [])
    {
        $this->attributes = $attributes;
        $this->entity = new UserEntity();
        
        if (isset($attributes['username'])) {
            $this->entity->setUsername($attributes['username']);
        }
        if (isset($attributes['role'])) {
            $this->entity->setRole($attributes['role']);
        }
    }

    public function setPassword(string $password): self
    {
        $this->entity->setPassword($password);
        return $this;
    }

    public function save(): bool
    {
        try {
            $entityManager = \getEntityManager();
            $entityManager->persist($this->entity);
            $entityManager->flush();
            return true;
        } catch (\Exception $e) {
            error_log("Error saving user: " . $e->getMessage());
            return false;
        }
    }

    public function getEntity(): UserEntity
    {
        return $this->entity;
    }
} 