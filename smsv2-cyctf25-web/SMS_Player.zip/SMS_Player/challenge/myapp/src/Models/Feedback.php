<?php

namespace Models;

use App\Entity\Feedback as FeedbackEntity;

class Feedback
{
    private FeedbackEntity $entity;
    private array $attributes;

    public function __construct(array $attributes = [])
    {
        $this->attributes = $attributes;
        $this->entity = new FeedbackEntity();
        
        if (isset($attributes['username'])) {
            $this->entity->setUsername($attributes['username']);
        }
        if (isset($attributes['feedback'])) {
            $this->entity->setFeedback($attributes['feedback']);
        }
    }

    public function save(): bool
    {
        try {
            $entityManager = \getEntityManager();
            $entityManager->persist($this->entity);
            $entityManager->flush();
            return true;
        } catch (\Exception $e) {
            error_log("Error saving feedback: " . $e->getMessage());
            return false;
        }
    }

    public function getEntity(): FeedbackEntity
    {
        return $this->entity;
    }
} 