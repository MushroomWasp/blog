<?php
include 'db.php'; 
session_start();

if (!isset($_SESSION['reset_user'])) {
    $error_message = "No reset request found. Please request a password reset first.";
    $show_form = false;
} else {
    $username = $_SESSION['reset_user'];
    $show_form = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $show_form) {
    $input_code = $_POST['code'];

    $user = findUserByUsername($username);

    if ($user) {
        if ($user->isVerificationCodeValid($input_code, 30)) { 
            if (isset($_POST['new_password'])) {
                $new_password = $_POST['new_password'];
                $user->setPassword($new_password);
                $user->clearVerificationCode();

                try {
                    $entityManager = getEntityManager();
                    $entityManager->persist($user);
                    $entityManager->flush();
                    
                    $success_message = "Password has been reset successfully!";
                    unset($_SESSION['reset_user']); 
                    header('Location: login.php'); 
                    exit;
                } catch (\Exception $e) {
                    $error_message = "Failed to reset the password. Please try again later.";
                }
            } else {
                $show_new_password_form = true;
            }
        } else {
            $error_message = "Invalid or expired reset code.";
        }
    } else {
        $error_message = "User not found.";
    }
}
?>

<?php include 'header.php'; ?>

<div class="hero-section fade-in">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="form-card">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!$show_form): ?>
                        <div class="text-center mb-4">
                            <h1><i class="fas fa-exclamation-triangle"></i> Reset Error</h1>
                            <p class="lead">Please request a password reset first.</p>
                        </div>
                        <div class="text-center">
                            <a href="forgot_password.php" class="btn btn-primary">
                                <i class="fas fa-key"></i> Request Reset
                            </a>
                        </div>
                    <?php elseif (isset($show_new_password_form)): ?>
                        <div class="text-center mb-4">
                            <h1><i class="fas fa-lock"></i> Set New Password</h1>
                            <p class="lead">Enter your new password below.</p>
                        </div>
                        <form action="reset.php" method="POST">
                            <div class="form-group">
                                <label for="new_password"><i class="fas fa-lock"></i> New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Enter your new password" required>
                            </div>
                            <input type="hidden" name="code" value="<?php echo htmlspecialchars($input_code); ?>">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-save"></i> Reset Password
                                </button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="text-center mb-4">
                            <h1><i class="fas fa-key"></i> Reset Password</h1>
                            <p class="lead">Enter the reset code sent to your account.</p>
                        </div>
                        <form action="reset.php" method="POST">
                            <div class="form-group">
                                <label for="code"><i class="fas fa-code"></i> Reset Code</label>
                                <input type="text" class="form-control" id="code" name="code" placeholder="Enter your reset code" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-check"></i> Verify Code
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                    
                    <div class="text-center mt-4">
                        <a href="login.php" class="text-decoration-none">
                            <i class="fas fa-arrow-left"></i> Back to Login
                        </a>
                    </div>
                    
                    <div class="text-center mt-3">
                        <a href="index.php" class="text-decoration-none">
                            <i class="fas fa-home"></i> Back to Home
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
