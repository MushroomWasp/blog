<?php
include 'db.php';
session_start();

if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['username'];
?>

<?php include 'header.php'; ?>

<div class="hero-section fade-in">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1><i class="fas fa-comments"></i> Admin Feedback Dashboard</h1>
                <p class="lead">Manage and review user feedback submissions</p>
            </div>
            <div class="col-md-4 text-end">
                <a href="dashboard.php" class="btn btn-outline-light me-2">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="logout.php" class="btn btn-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="card-title" id="total-feedback">0</h4>
                            <p class="card-text">Total Feedback</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-comments fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="card-title" id="recent-feedback">0</h4>
                            <p class="card-text">Recent (7 days)</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="card-title" id="unique-users">0</h4>
                            <p class="card-text">Unique Users</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="card-title" id="today-feedback">0</h4>
                            <p class="card-text">Today</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-calendar-day fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Controls and Filters -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2">
                            <label for="search-input" class="form-label">
                                <i class="fas fa-search"></i> Search
                            </label>
                            <input type="text" class="form-control" id="search-input" placeholder="Search feedback...">
                        </div>
                        <div class="col-md-2">
                            <label for="filter-user" class="form-label">
                                <i class="fas fa-user"></i> User Filter
                            </label>
                            <select class="form-select" id="filter-user">
                                <option value="">All Users</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="filter-date" class="form-label">
                                <i class="fas fa-calendar"></i> Date Filter
                            </label>
                            <select class="form-select" id="filter-date">
                                <option value="">All Time</option>
                                <option value="today">Today</option>
                                <option value="week">This Week</option>
                                <option value="month">This Month</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">&nbsp;</label>
                            <button class="btn btn-primary w-100" onclick="refreshData()">
                                <i class="fas fa-sync-alt"></i> Refresh
                            </button>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">&nbsp;</label>
                            <button class="btn btn-success w-100" onclick="showIdSearch()" >
                                <i class="fas fa-search"></i> ID Search
                            </button>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">&nbsp;</label>
                            <button class="btn btn-outline-secondary w-100" onclick="resetToAllFeedback()" title="Show all feedback">
                                <i class="fas fa-list"></i> Show All
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">
                        <i class="fas fa-chart-bar"></i> Quick Actions
                    </h6>
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-success btn-sm" onclick="exportFeedback()">
                            <i class="fas fa-download"></i> Export to CSV
                        </button>
                        <button class="btn btn-outline-info btn-sm" onclick="showAnalytics()">
                            <i class="fas fa-chart-line"></i> View Analytics
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Feedback Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="fas fa-list"></i> Feedback Submissions
                <span class="badge bg-primary ms-2" id="feedback-count">0</span>
            </h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="feedback-table">
                    <thead class="table-dark">
                        <tr>
                            <th>
                                <input type="checkbox" id="select-all" class="form-check-input">
                            </th>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Feedback</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="feedback-tbody">
                        <tr>
                            <td colspan="6" class="text-center text-muted">
                                <i class="fas fa-spinner fa-spin"></i> Loading feedback...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="d-flex align-items-center">
                <span class="text-muted me-3">Show:</span>
                <select class="form-select form-select-sm" style="width: auto;" id="page-size">
                    <option value="10">10</option>
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
                <span class="text-muted ms-3">entries per page</span>
            </div>
        </div>
        <div class="col-md-6">
            <nav aria-label="Feedback pagination">
                <ul class="pagination justify-content-end mb-0" id="pagination">
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Feedback Detail Modal -->
<div class="modal fade" id="feedbackModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-comment"></i> Feedback Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="feedback-modal-body">
                <!-- Content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" onclick="deleteFeedback()">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ID Search Modal -->
<div class="modal fade" id="idSearchModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-search"></i> Search Feedback by ID
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="id-search-input" class="form-label">Feedback ID</label>
                    <input type="text" class="form-control" id="id-search-input" placeholder="Enter feedback ID to search...">
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="searchById()">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Analytics Modal -->
<div class="modal fade" id="analyticsModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-chart-line"></i> Feedback Analytics
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <canvas id="feedbackChart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <canvas id="userChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let allFeedback = [];
let filteredFeedback = [];
let currentPage = 1;
let pageSize = 25;
let selectedFeedbackId = null;

document.addEventListener('DOMContentLoaded', function() {
    loadFeedback();
    setupEventListeners();
});

function setupEventListeners() {
    document.getElementById('search-input').addEventListener('input', function() {
        filterFeedback();
    });

    document.getElementById('filter-user').addEventListener('change', function() {
        filterFeedback();
    });

    document.getElementById('filter-date').addEventListener('change', function() {
        filterFeedback();
    });

    document.getElementById('page-size').addEventListener('change', function() {
        pageSize = parseInt(this.value);
        currentPage = 1;
        renderFeedback();
    });

    document.getElementById('select-all').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.feedback-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });

    document.getElementById('id-search-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchById();
        }
    });


}

function loadFeedback() {
    fetch('feedback.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showAlert('Error loading feedback: ' + data.error, 'danger');
                return;
            }
            
            allFeedback = data;
            filteredFeedback = [...allFeedback];
            
            updateStatistics();
            populateUserFilter();
            renderFeedback();
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Failed to load feedback data', 'danger');
        });
}

function updateStatistics() {
    const total = allFeedback.length;
    const today = new Date().toDateString();
    const todayCount = allFeedback.filter(f => new Date(f.date).toDateString() === today).length;
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentCount = allFeedback.filter(f => new Date(f.date) >= weekAgo).length;
    const uniqueUsers = new Set(allFeedback.map(f => f.username)).size;

    document.getElementById('total-feedback').textContent = total;
    document.getElementById('today-feedback').textContent = todayCount;
    document.getElementById('recent-feedback').textContent = recentCount;
    document.getElementById('unique-users').textContent = uniqueUsers;
}

function populateUserFilter() {
    const users = [...new Set(allFeedback.map(f => f.username))].sort();
    const select = document.getElementById('filter-user');
    
    select.innerHTML = '<option value="">All Users</option>';
    
    users.forEach(user => {
        const option = document.createElement('option');
        option.value = user;
        option.textContent = user;
        select.appendChild(option);
    });
}

function filterFeedback() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const userFilter = document.getElementById('filter-user').value;
    const dateFilter = document.getElementById('filter-date').value;

    filteredFeedback = allFeedback.filter(feedback => {
        const matchesSearch = !searchTerm || 
            feedback.username.toLowerCase().includes(searchTerm) ||
            feedback.feedback.toLowerCase().includes(searchTerm);

        const matchesUser = !userFilter || feedback.username === userFilter;

        let matchesDate = true;
        if (dateFilter) {
            const feedbackDate = new Date(feedback.date);
            const now = new Date();
            
            switch(dateFilter) {
                case 'today':
                    matchesDate = feedbackDate.toDateString() === now.toDateString();
                    break;
                case 'week':
                    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    matchesDate = feedbackDate >= weekAgo;
                    break;
                case 'month':
                    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                    matchesDate = feedbackDate >= monthAgo;
                    break;
            }
        }

        return matchesSearch && matchesUser && matchesDate;
    });

    currentPage = 1;
    renderFeedback();
}

function renderFeedback() {
    const tbody = document.getElementById('feedback-tbody');
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const pageData = filteredFeedback.slice(startIndex, endIndex);

    if (pageData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted">
                    <i class="fas fa-inbox"></i> No feedback found
                </td>
            </tr>
        `;
        document.getElementById('feedback-count').textContent = '0';
        renderPagination();
        return;
    }

    tbody.innerHTML = pageData.map(feedback => `
        <tr>
            <td>
                <input type="checkbox" class="form-check-input feedback-checkbox" value="${feedback.id}">
            </td>
            <td>${feedback.id}</td>
            <td>
                <span class="badge bg-primary">${feedback.username}</span>
            </td>
            <td>
                <div class="feedback-preview">
                    ${feedback.feedback.length > 100 ? 
                        feedback.feedback.substring(0, 100) + '...' : 
                        feedback.feedback}
                </div>
            </td>
            <td>
                <small class="text-muted">
                    ${formatDate(feedback.date)}
                </small>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="viewFeedback(${feedback.id})">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteFeedback(${feedback.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');

    document.getElementById('feedback-count').textContent = filteredFeedback.length;
    renderPagination();
}

function renderPagination() {
    const totalPages = Math.ceil(filteredFeedback.length / pageSize);
    const pagination = document.getElementById('pagination');
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }

    let paginationHTML = '';
    
    paginationHTML += `
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i>
            </a>
        </li>
    `;

    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
            paginationHTML += `
                <li class="page-item ${i === currentPage ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
                </li>
            `;
        } else if (i === currentPage - 3 || i === currentPage + 3) {
            paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }

    paginationHTML += `
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">
                <i class="fas fa-chevron-right"></i>
            </a>
        </li>
    `;

    pagination.innerHTML = paginationHTML;
}

function changePage(page) {
    const totalPages = Math.ceil(filteredFeedback.length / pageSize);
    if (page >= 1 && page <= totalPages) {
        currentPage = page;
        renderFeedback();
    }
}

function viewFeedback(id) {
    const feedback = allFeedback.find(f => f.id == id);
    if (!feedback) return;

    selectedFeedbackId = id;
    
    document.getElementById('feedback-modal-body').innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <h6><i class="fas fa-user"></i> User Information</h6>
                <p><strong>Username:</strong> ${feedback.username}</p>
                <p><strong>Feedback ID:</strong> ${feedback.id}</p>
                <p><strong>Submitted:</strong> ${formatDate(feedback.date)}</p>
            </div>
            <div class="col-md-6">
                <h6><i class="fas fa-clock"></i> Time Information</h6>
                <p><strong>Date:</strong> ${new Date(feedback.date).toLocaleDateString()}</p>
                <p><strong>Time:</strong> ${new Date(feedback.date).toLocaleTimeString()}</p>
                <p><strong>Age:</strong> ${getTimeAgo(feedback.date)}</p>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-12">
                <h6><i class="fas fa-comment"></i> Feedback Content</h6>
                <div class="alert alert-info">
                    ${feedback.feedback.replace(/\n/g, '<br>')}
                </div>
            </div>
        </div>
    `;

    new bootstrap.Modal(document.getElementById('feedbackModal')).show();
}

function deleteFeedback(id = null) {
    const feedbackId = id || selectedFeedbackId;
    if (!feedbackId) return;

    if (confirm('Are you sure you want to delete this feedback? This action cannot be undone.')) {
        allFeedback = allFeedback.filter(f => f.id != feedbackId);
        filteredFeedback = filteredFeedback.filter(f => f.id != feedbackId);
        
        updateStatistics();
        renderFeedback();
        
        const modal = bootstrap.Modal.getInstance(document.getElementById('feedbackModal'));
        if (modal) modal.hide();
        
        showAlert('Feedback deleted successfully', 'success');
    }
}

function refreshData() {
    loadFeedback();
    showAlert('Data refreshed successfully', 'success');
}

function exportFeedback() {
    const csvContent = "data:text/csv;charset=utf-8," 
        + "ID,Username,Feedback,Date\n"
        + filteredFeedback.map(f => 
            `${f.id},"${f.username}","${f.feedback.replace(/"/g, '""')}","${f.date}"`
        ).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "feedback_export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showAlert('Feedback exported to CSV successfully', 'success');
}

function showIdSearch() {
    document.getElementById('id-search-input').value = '';
    
    new bootstrap.Modal(document.getElementById('idSearchModal')).show();
}

function searchById() {
    const id = document.getElementById('id-search-input').value.trim();
    
    if (!id) {
        showAlert('Please enter a feedback ID to search', 'warning');
        return;
    }
    
    showAlert(`Searching for feedback by ID: ${id}`, 'info');
    
    fetch(`search_feedback.php?feedback_id=${encodeURIComponent(id)}`)
        .then(response => response.json())
        .then(data => {
            const modal = bootstrap.Modal.getInstance(document.getElementById('idSearchModal'));
            if (modal) modal.hide();
            
            if (data.error) {
                showAlert('Error searching feedback: ' + data.error, 'danger');
                return;
            }
            
            if (data.success) {
                allFeedback = data.data;
                filteredFeedback = [...allFeedback];
                
                updateStatistics();
                populateUserFilter();
                renderFeedback();
                
                showAlert(`Found ${data.count} feedback entries for ID`, 'success');
                
                document.getElementById('search-input').value = id;
            } else {
                allFeedback = data;
                filteredFeedback = [...allFeedback];
                
                updateStatistics();
                populateUserFilter();
                renderFeedback();
                
                showAlert(`Found ${data.length} feedback entries for ID`, 'success');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Failed to search feedback by ID', 'danger');
        });
}

function resetToAllFeedback() {
    document.getElementById('search-input').value = '';
    document.getElementById('filter-user').value = '';
    document.getElementById('filter-date').value = '';
    
    loadFeedback();
    
    showAlert('Reset to show all feedback', 'info');
}

function showAnalytics() {
    const userCounts = {};
    const dateCounts = {};
    
    allFeedback.forEach(f => {
        userCounts[f.username] = (userCounts[f.username] || 0) + 1;
        
        const date = new Date(f.date).toDateString();
        dateCounts[date] = (dateCounts[date] || 0) + 1;
    });

    new bootstrap.Modal(document.getElementById('analyticsModal')).show();
    
    setTimeout(() => {
        renderCharts(userCounts, dateCounts);
    }, 100);
}

function renderCharts(userCounts, dateCounts) {
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
        return 'Today';
    } else if (diffDays === 2) {
        return 'Yesterday';
    } else if (diffDays <= 7) {
        return `${diffDays - 1} days ago`;
    } else {
        return date.toLocaleDateString();
    }
}

function getTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays < 7) return `${diffDays - 1} days ago`;
    if (diffDays < 30) return `${Math.floor((diffDays - 1) / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor((diffDays - 1) / 30)} months ago`;
    return `${Math.floor((diffDays - 1) / 365)} years ago`;
}

function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}
</script>

<?php include 'footer.php'; ?> 