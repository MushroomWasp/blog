<?php
include 'db.php';

session_start();

if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    header('Location: login.php');
    exit();
}

header('Content-Type: application/json');

if (isset($_GET['feedback_id']) && !empty($_GET['feedback_id'])) {
    $id = $_GET['feedback_id'];
    try {
        $feedbackModels = findFeedbackById($id);
        $feedbacks = array_map(function($feedback) {
            return $feedback->toArray();
        }, $feedbackModels);
        
        echo json_encode([
            'success' => true,
            'data' => $feedbacks,
            'count' => count($feedbacks),
            'id' => $id
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'error' => 'Search failed: ' . $e->getMessage(),
            'id' => $id
        ]);
    }
} else {
    echo json_encode(['error' => 'ID parameter is required']);
}
?> 