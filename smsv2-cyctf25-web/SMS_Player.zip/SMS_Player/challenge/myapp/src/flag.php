<?php
include 'db.php'; 

session_start();

if (!$_SESSION['admin'])
{
    header('Location: login.php');
    die();
}

header('Content-Type: application/json');

$flag = getenv('FLAG');

if ($flag === false) {
    echo json_encode(['error' => 'Error getting flag']);
} else {
    echo json_encode(['flag' => $flag]);
}
?>
