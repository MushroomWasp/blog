<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'users')]
class User
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private string $username = '';

    #[ORM\Column(type: 'string', length: 255)]
    private string $password = '';

    #[ORM\Column(type: 'string', length: 50, options: ['default' => 'user'])]
    private string $role = 'user';

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $code = null;

    #[ORM\Column(type: 'datetime', nullable: true, name: 'code_created_at')]
    private ?\DateTime $codeCreatedAt = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true, name: 'api_key')]
    private ?string $apiKey = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUsername(): string
    {
        return $this->username;
    }

    public function setUsername(string $username): self
    {
        $this->username = $username;
        return $this;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = password_hash($password, PASSWORD_DEFAULT);
        return $this;
    }

    public function verifyPassword(string $password): bool
    {
        return password_verify($password, $this->password);
    }

    public function getRole(): string
    {
        return $this->role;
    }

    public function setRole(string $role): self
    {
        $this->role = $role;
        return $this;
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }
    public function isDev(): bool
    {
        return $this->role === 'dev';
    }

    public function hasRole(string $role): bool
    {
        return $this->role === $role;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(?string $code): self
    {
        $this->code = $code;
        return $this;
    }

    public function getCodeCreatedAt(): ?\DateTime
    {
        return $this->codeCreatedAt;
    }

    public function setCodeCreatedAt(?\DateTime $codeCreatedAt): self
    {
        $this->codeCreatedAt = $codeCreatedAt;
        return $this;
    }

    public function setVerificationCode(string $code): self
    {
        $this->code = $code;
        $this->codeCreatedAt = new \DateTime();
        return $this;
    }

    public function isVerificationCodeValid(string $code, int $expiryMinutes = 30): bool
    {
        if (!$this->code || $this->code !== $code) {
            return false;
        }

        if (!$this->codeCreatedAt) {
            return false;
        }

        $now = new \DateTime();
        $diff = $now->diff($this->codeCreatedAt);

        return $diff->i < $expiryMinutes;
    }

    public function clearVerificationCode(): self
    {
        $this->code = null;
        $this->codeCreatedAt = null;
        return $this;
    }

    public function getApiKey(): ?string
    {
        return $this->apiKey;
    }

    public function setApiKey(?string $apiKey): self
    {
        $this->apiKey = $apiKey;
        return $this;
    }

    public function generateApiKey(): self
    {
        $this->apiKey = bin2hex(random_bytes(32));
        return $this;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'username' => $this->username,
            'role' => $this->role,
            'code' => $this->code,
            'code_created_at' => $this->codeCreatedAt ? $this->codeCreatedAt->format('Y-m-d H:i:s') : null,
            'api_key' => $this->apiKey
        ];
    }
} 