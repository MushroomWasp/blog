<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'uploads')]
class Upload
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255, name: 'file_name')]
    private string $fileName = '';

    #[ORM\Column(type: 'string', length: 255, name: 'user_hash')]
    private string $userHash = '';

    #[ORM\Column(type: 'datetime', name: 'uploaded_at')]
    private \DateTime $uploadedAt;

    #[ORM\Column(type: 'string', length: 255, name: 'calculated_hash')]
    private string $calculatedHash = '';

    public function __construct()
    {
        $this->uploadedAt = new \DateTime();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFileName(): string
    {
        return $this->fileName;
    }

    public function setFileName(string $fileName): self
    {
        $this->fileName = $fileName;
        return $this;
    }

    public function getUserHash(): string
    {
        return $this->userHash;
    }

    public function setUserHash(string $userHash): self
    {
        $this->userHash = $userHash;
        return $this;
    }

    public function getUploadedAt(): \DateTime
    {
        return $this->uploadedAt;
    }

    public function setUploadedAt(\DateTime $uploadedAt): self
    {
        $this->uploadedAt = $uploadedAt;
        return $this;
    }

    public function getCalculatedHash(): string
    {
        return $this->calculatedHash;
    }

    public function setCalculatedHash(string $calculatedHash): self
    {
        $this->calculatedHash = $calculatedHash;
        return $this;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'file_name' => $this->fileName,
            'user_hash' => $this->userHash,
            'uploaded_at' => $this->uploadedAt->format('Y-m-d H:i:s'),
            'calculated_hash' => $this->calculatedHash
        ];
    }
} 