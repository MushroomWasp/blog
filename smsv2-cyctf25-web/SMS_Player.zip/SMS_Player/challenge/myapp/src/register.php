<?php
session_start();
include 'db.php';
include 'header.php';

$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = $register_err = $register_success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        $username = trim($_POST["username"]);
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if ($password != $confirm_password) {
            $confirm_password_err = "Password did not match.";
        }
    }

    if (empty($username_err) && empty($password_err) && empty($confirm_password_err)) {
        try {
            $existingUser = findUserByUsername($username);
            if ($existingUser) {
                $username_err = "This username is already taken.";
            } else {
                $user = new \Models\User([
                    'username' => $username,
                    'role' => 'user'
                ]);
                $user->setPassword($password);
                
                if ($user->save()) {
                    $register_success = "Registration successful! You can now <a href='login.php' class='alert-link'>login</a>.";
                    $username = $password = $confirm_password = "";
                } else {
                    $register_err = "Registration failed. Please try again.";
                }
            }
        } catch (PDOException $e) {
            $register_err = "Database error: " . $e->getMessage();
        }
    }
}
?>
<div class="hero-section fade-in">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="form-card">
                    <div class="text-center mb-4">
                        <h1><i class="fas fa-user-plus"></i> Register</h1>
                        <p class="lead">Create your account to get started!</p>
                    </div>
                    <?php if (!empty($register_success)): ?>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle"></i> <?php echo $register_success; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($register_err)): ?>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo $register_err; ?>
                        </div>
                    <?php endif; ?>
                    <form action="register.php" method="POST">
                        <div class="form-group mb-3">
                            <label for="username"><i class="fas fa-user"></i> Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" value="<?php echo htmlspecialchars($username); ?>" required>
                            <?php if (!empty($username_err)): ?>
                                <div class="alert alert-danger mt-2 py-1" role="alert" style="font-size:0.95em;">
                                    <i class="fas fa-exclamation-circle"></i> <?php echo $username_err; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <label for="password"><i class="fas fa-lock"></i> Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                            <?php if (!empty($password_err)): ?>
                                <div class="alert alert-danger mt-2 py-1" role="alert" style="font-size:0.95em;">
                                    <i class="fas fa-exclamation-circle"></i> <?php echo $password_err; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-4">
                            <label for="confirm_password"><i class="fas fa-lock"></i> Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                            <?php if (!empty($confirm_password_err)): ?>
                                <div class="alert alert-danger mt-2 py-1" role="alert" style="font-size:0.95em;">
                                    <i class="fas fa-exclamation-circle"></i> <?php echo $confirm_password_err; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-user-plus"></i> Register
                            </button>
                        </div>
                    </form>
                    <div class="text-center mt-4">
                        <a href="login.php" class="text-decoration-none">
                            <i class="fas fa-sign-in-alt"></i> Already have an account? Login here
                        </a>
                    </div>
                    <div class="text-center mt-3">
                        <a href="index.php" class="text-decoration-none">
                            <i class="fas fa-home"></i> Back to Home
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?> 