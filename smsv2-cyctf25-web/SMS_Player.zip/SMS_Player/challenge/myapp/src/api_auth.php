<?php

require_once __DIR__ . '/doctrine.php';

function getApiKeyFromRequest(): ?string
{
    $headers = getallheaders();
    
    if (isset($headers['X-API-Key'])) {
        return $headers['X-API-Key'];
    }

    return null;
}

function authenticateApiRequest(): ?\App\Entity\User
{
    $apiKey = getApiKeyFromRequest();
    
    if (!$apiKey) {
        return null;
    }
    
    return findUserByApiKey($apiKey);
}

function requireApiAuth(): \App\Entity\User
{
    $user = authenticateApiRequest();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized - Invalid API key']);
        exit;
    }
    
    if (!$user->isDev()) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden - Dev access required']);
        exit;
    }
    
    return $user;
}

function requireSessionAuth(): \App\Entity\User
{
    if (!isset($_SESSION['username'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized - Dev session required']);
        exit;
    }
    
    $user = findUserByUsername($_SESSION['username']);
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized - Invalid dev session']);
        exit;
    }
    
    if (!$user->hasRole('dev')) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden - Dev role required']);
        exit;
    }
    
    return $user;
}

function sendJsonResponse($data, $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

function sendErrorResponse($message, $statusCode = 400): void
{
    sendJsonResponse(['error' => $message], $statusCode);
} 