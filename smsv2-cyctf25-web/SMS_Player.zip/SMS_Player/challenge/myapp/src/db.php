<?php
session_start();

require_once __DIR__ . '/doctrine.php';

?>
