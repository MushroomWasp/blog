<?php
include 'db.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    
    if (empty($old_password) || empty($new_password)) {
        $error_message = "All fields are required.";
    } elseif (strlen($new_password) < 6) {
        $error_message = "New password must be at least 6 characters long.";
    } else {
        $user = findUserByUsername($_SESSION['username']);
        
        if ($user) {
            if (!$user->verifyPassword($old_password)) {
                $error_message = "Old password is incorrect.";
            } else {
                $user->setPassword($new_password);
                
                try {
                    $entityManager = getEntityManager();
                    $entityManager->persist($user);
                    $entityManager->flush();
                    $success_message = "Password updated successfully!";
                } catch (\Exception $e) {
                    $error_message = "Failed to update password. Please try again.";
                }
            }
        } else {
            $error_message = "User not found. Please try again.";
        }
    }
}
?>

<?php include 'header.php'; ?>

<div class="hero-section fade-in">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="form-card">
                    <div class="text-center mb-4">
                        <h1><i class="fas fa-key"></i> Change Password</h1>
                        <p class="lead">Update your admin password</p>
                    </div>
                    
                    <?php if ($success_message): ?>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error_message): ?>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form action="update.php" method="POST">
                        <div class="form-group mb-3">
                            <label for="old_password">
                                <i class="fas fa-lock"></i> Old Password
                            </label>
                            <input type="password" 
                                   class="form-control" 
                                   id="old_password" 
                                   name="old_password" 
                                   placeholder="Enter your current password" 
                                   required>
                        </div>
                        
                        <div class="form-group mb-4">
                            <label for="new_password">
                                <i class="fas fa-key"></i> New Password
                            </label>
                            <input type="password" 
                                   class="form-control" 
                                   id="new_password" 
                                   name="new_password" 
                                   placeholder="Enter your new password" 
                                   required>
                            <small class="form-text text-muted">
                                Password must be at least 6 characters long
                            </small>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Password
                            </button>
                            <a href="dashboard.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Dashboard
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('new_password').addEventListener('input', function() {
    const password = this.value;
    const strength = checkPasswordStrength(password);
    updatePasswordStrengthIndicator(strength);
});

function checkPasswordStrength(password) {
    let strength = 0;
    
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    
    return strength;
}

function updatePasswordStrengthIndicator(strength) {
    const input = document.getElementById('new_password');
    const feedback = input.parentNode.querySelector('.form-text');
    
    if (!feedback) return;
    
    const messages = [
        'Very Weak',
        'Weak', 
        'Fair',
        'Good',
        'Strong'
    ];
    
    const colors = [
        'text-danger',
        'text-warning',
        'text-info', 
        'text-primary',
        'text-success'
    ];
    
    feedback.className = `form-text ${colors[strength - 1] || 'text-muted'}`;
    feedback.innerHTML = `Password strength: ${messages[strength - 1] || 'Very Weak'}`;
}
</script>

<?php include 'footer.php'; ?> 