<?php
$con = mysqli_connect("db", "ict", "db_pass", "ict");

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

$query_drop = "DROP TABLE IF EXISTS users;";
$query_create = "
    CREATE TABLE users (
        id INT(11) NOT NULL AUTO_INCREMENT,
        username VARCHAR(500) NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'user',
        code VARCHAR(255) NULL,
        code_created_at DATETIME NULL,
        api_key VARCHAR(255) NULL,
        PRIMARY KEY (id),
        UNIQUE KEY unique_username (username)
    );
";

if (mysqli_query($con, $query_drop)) {
    echo "Table 'users' dropped successfully. <br>";
} else {
    echo "Error dropping table: " . mysqli_error($con);
}
if (mysqli_query($con, $query_create)) {
    echo "Table 'users' created successfully. <br>";
} else {
    echo "Error creating table: " . mysqli_error($con);
}

$query2 = "CREATE TABLE IF NOT EXISTS uploads ( 
        id INT(11) NOT NULL AUTO_INCREMENT, 
        file_name VARCHAR(255) NOT NULL,
        user_hash VARCHAR(255) NOT NULL, 
        uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        calculated_hash VARCHAR(255) NULL, 
        PRIMARY KEY (id) 
    );
";

if (mysqli_query($con, $query2)) {
    echo "Table 'uploads' created or already exists. <br>";
} else {
    echo "Error creating table: " . mysqli_error($con);
}

$query3_drop = "DROP TABLE IF EXISTS feedback;";
$query3_create = "CREATE TABLE feedback (
    id INT(11) NOT NULL AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    feedback TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, 
    PRIMARY KEY (id)
);";

if (mysqli_query($con, $query3_drop)) {
    echo "Table 'feedback' dropped successfully. <br>";
} else {
    echo "Error dropping table: " . mysqli_error($con);
}
if (mysqli_query($con, $query3_create)) {
    echo "Table 'feedback' created successfully. <br>";
} else {
    echo "Error creating table: " . mysqli_error($con);
}


$username = 'admin';
$password = 'admin';  

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$insertQuery = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashedPassword', 'admin')";

if (mysqli_query($con, $insertQuery)) {
    echo "Admin user created successfully.<br>";
} else {
    echo "Error inserting admin user: " . mysqli_error($con) . "<br>";
}

$dev_username = 'dev';
$dev_password = 'dev_pass';  

$dev_hashedPassword = password_hash($dev_password, PASSWORD_DEFAULT);

$dev_insertQuery = "INSERT INTO users (username, password, role) VALUES ('$dev_username', '$dev_hashedPassword', 'dev')";

if (mysqli_query($con, $dev_insertQuery)) {
    echo "Dev user created successfully.";
} else {
    echo "Error inserting dev user: " . mysqli_error($con);
}

mysqli_close($con);
?>
