#!/bin/bash

echo "Waiting for the database to be ready..."
  sleep 10
echo "Database is ready!"

echo "Running load.php to initialize the database..."
php /var/load.php

echo "Starting Apache server..."
apache2-foreground
