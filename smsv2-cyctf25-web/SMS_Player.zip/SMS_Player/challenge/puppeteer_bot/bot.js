const puppeteer = require('puppeteer');
const fs = require('fs');
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const querystring = require('querystring');

const app = express();
app.use(bodyParser.json());

const CONFIG = {
    APPLIMITTIME: Number(process.env['APPLIMITTIME'] || "60"),
    APPLIMIT: Number(process.env['APPLIMIT'] || "5")
};

console.table(CONFIG);

function getBrowserPath() {
    const browserPaths = [
        "/usr/bin/chromium-browser",
        "/usr/bin/google-chrome",
        "/usr/bin/chromium"
    ];
    for (const browserPath of browserPaths) {
        if (fs.existsSync(browserPath)) {
            return browserPath;
        }
    }
    throw new Error("No browser found");
}

const browserArgs = {
    executablePath: getBrowserPath(),
    headless: true,
    args: [
        '--disable-dev-shm-usage',
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-gpu',
        '--disable-translate',
        '--disable-software-rasterizer',
        '--disable-xss-auditor'
    ],
    ignoreHTTPSErrors: true
};

let initBrowser = null;

console.log("Bot started...");

async function loginToAdmin() {
    try {
        console.log("Logging into dev...");

        const loginData = querystring.stringify({
            username: 'dev',
            password: 'dev_pass'
        });

        const response = await axios.post('http://web:80/login.php', loginData, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(loginData)
            },
            maxRedirects: 0, 
            validateStatus: function (status) {
                return status >= 200 && status < 400; 
            }
        });

        if (response.status === 200 || response.status === 302) {
            console.log("Login successful.");
            return response.headers['set-cookie']; 
        } else {
            console.error("Login failed with status:", response.status);
            return null;
        }
    } catch (error) {
        console.error("Error during login:", error);
        return null;
    }
}

async function visitUrl(urlToVisit) {
    try {
        if (!initBrowser) {
            initBrowser = await puppeteer.launch(browserArgs);
        }
        const page = await initBrowser.newPage();

        const cookies = await loginToAdmin();

        if (!cookies) {
            console.error("Login failed. Cannot visit URL.");
            await page.close(); 
            return false;
        }

        const cookieObjects = cookies.map(cookie => {
            try {
                const [nameValue, ...rest] = cookie.split(';');
                const [name, value] = nameValue.split('=');
                const cookieObj = {
                    name: name.trim(),
                    value: value.trim(),
                    domain: 'web',
                    path: '/'
                };
                
                rest.forEach(attr => {
                    const [attrName, attrValue] = attr.trim().split('=');
                    const lowerAttrName = attrName.toLowerCase();
                    if (lowerAttrName === 'httponly') {
                        cookieObj.httpOnly = true;
                    } else if (lowerAttrName === 'secure') {
                        cookieObj.secure = true;
                    } else if (lowerAttrName === 'samesite') {
                        cookieObj.sameSite = attrValue;
                    } else if (lowerAttrName === 'expires') {
                        cookieObj.expires = new Date(attrValue);
                    }
                });
                
                return cookieObj;
            } catch (error) {
                console.error('Error parsing cookie:', cookie, error);
                return null;
            }
        }).filter(cookie => cookie !== null);

        await page.setCookie(...cookieObjects);
        console.log(`Bot visiting ${urlToVisit}`);
        console.log(`Set ${cookieObjects.length} cookies for authentication`);
        console.log('Cookie details:', cookieObjects.map(c => ({ name: c.name, domain: c.domain, path: c.path })));
        
        page.on('console', (msg) => {
            console.log(`PAGE LOG: ${msg.text()}`);
        });
        
        page.on('pageerror', (error) => {
            console.error(`PAGE ERROR: ${error.message}`);
        });

        await page.setDefaultNavigationTimeout(30000);
        await page.goto(urlToVisit, { waitUntil: 'networkidle2' });
        
        await page.waitForTimeout(2000);
        
        console.log("Visit complete, closing page...");
        await page.close(); 
        return true;
    } catch (error) {
        console.error("Error during bot visit:", error);
        return false;
    }
}

app.post('/visit', async (req, res) => {
    const { url } = req.body;
    if (!url) {
        return res.status(400).json({ error: "URL is required" });
    }

    const normalizedUrl = String(url).trim();
    if (!/^https?:\/\/.+/i.test(normalizedUrl)) {
        return res.status(400).json({ error: "URL must start with http:// or https://" });
    }

    console.log(`Received URL to visit: ${normalizedUrl}`);
    const visitSuccess = await visitUrl(normalizedUrl);
    if (visitSuccess) {
        res.json({ status: "Bot visited the URL successfully" });
    } else {
        res.status(500).json({ error: "Bot failed to visit the URL" });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Bot server is running on port ${PORT}`);
});
